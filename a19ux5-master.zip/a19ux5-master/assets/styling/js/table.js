showTable("");
displayCheckbox();
function displayCheckbox(){
	let div1 = document.getElementById("checkDiv");
	let div2 = document.getElementById("checkDiv2");
	if(o == 0){
		div1.style.display = "none";
		div2.style.display = "none";
	}

}
function showTable(str) {
	let box = document.getElementById("checker");
	let boxsignature = document.getElementById("checkersignature");
	let isChecked="0";
	let isSignatureChecked="0";
	if(box!=null){
		if(box.checked == true){
			isChecked = "1";
		}
		else{
			isChecked = "0";
		}
	}
	if(boxsignature!=null){
		if(boxsignature.checked == true){
			isSignatureChecked = "1";
		}
		else{
			isSignatureChecked = "0";
		}
	}
	let xhttp;
	xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			document.getElementById("tablecontent").innerHTML = this.responseText
		}
	};
	xhttp.open("GET", "liveSearch?q="+str+"&int="+o+"&box="+isChecked+"&sigbox="+isSignatureChecked, true);
	xhttp.send();
}
function changeSelectedResident(resId) {
	let xhttp;
	xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			window.location = link;
		}
	};
	xhttp.open("GET", "setResidentId?res=" + resId, true);
	xhttp.send();
}


let imgName = document.getElementById("imgName");
let imgRoom = document.getElementById("imgRoom");
let imgTime = document.getElementById("imgTime");
let images = [imgName, imgRoom, imgTime];
function sortTable(n) {
	let table, rows, switching, i, x, y, shouldSwitch, sortingOrder, switchcount = 0;
	table = document.getElementById("residentTable");
	switching = true;

	sortingOrder = "asc";

	while (switching) {
		switching = false;
		rows = table.rows;
		for (i = 1; i < (rows.length - 1); i++) {
			shouldSwitch = false;
			/* Get the two elements you want to compare,
			one from current row and one from the next: */
			x = rows[i].getElementsByTagName("TD")[n];
			y = rows[i + 1].getElementsByTagName("TD")[n];
			/* Check if the two rows should switch place,
			based on the direction, asc or desc: */
			if (sortingOrder == "asc") {
				if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
					// If so, mark as a switch and break the loop:
					shouldSwitch = true;
					break;
				}
			} else if (sortingOrder == "desc") {
				if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
					// If so, mark as a switch and break the loop:
					shouldSwitch = true;
					break;
				}
			}
		}
		if (shouldSwitch) {
			/* If a switch has been marked, make the switch
			and mark that a switch has been done: */
			rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
			switching = true;
			// Each time a switch is done, increase this count by 1:
			switchcount ++;
		} else {
			/* If no switching has been done AND the direction is "asc",
			set the direction to "desc" and run the while loop again. */
			if (switchcount == 0 && sortingOrder == "asc") {
				sortingOrder = "desc";
				switching = true;
			}
		}
	}
	for(let i = 0; i<images.length; i++){
		if(i===n){
			if(sortingOrder == "asc"){
				images[i].src = "../../assets/icons/up-arrow.svg";
			}
			else if(sortingOrder == "desc"){
				images[i].src = "../../assets/icons/down-arrow.svg";
			}
		}
		else{
			images[i].src = "../../assets/icons/double-arrow.svg";
		}

	}
}
