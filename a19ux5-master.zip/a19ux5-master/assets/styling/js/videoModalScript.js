// Get the modal
let videoModal = document.getElementById('videoModal');

function openVideoModal() {
	videoModal.style.display = "block";
	let video = document.getElementById("video");
	video.src = video.src + (video.src.indexOf('?') < 0 ? '?' : '&') + 'autoplay=1';
}
function closeVideoModal() {
	videoModal.style.display = "none";
	let video = document.getElementById("video");
	video.src = video.src.replace('&autoplay=1', '').replace('?autoplay=1', '');
}

