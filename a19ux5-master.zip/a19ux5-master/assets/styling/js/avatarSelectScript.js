// Using code from https://codepen.io/frazerwilson/pen/qEdQzq

$(document).ready(function(){
	//Center the "info" bubble in the  "circle" div
	const divCircle = $("#divCircle");
	const middleBubble = $("#middleBubble");
	const divTop = (divCircle.height() - middleBubble.height()) / 2;
	const divLeft = (divCircle.width() - middleBubble.width()) / 2;
	middleBubble.css("top",divTop + "px");
	middleBubble.css("left",divLeft + "px");

	//Arrange the icons in a circle centered in the div
	const divCircleImg = $("#divCircle img");
	const numItems = divCircleImg.length; //How many items are in the circle?
	let start = 0.0; //the angle to put the first image at. a number between 0 and 2pi
	const step = (4 * Math.PI) / numItems; //calculate the amount of space to put between the items.

	//Now loop through the buttons and position them in a circle
	divCircleImg.each(function( index ) {
		const radius = (divCircle.width() - $(this).width()) / 2.3; //The radius is the distance from the center of the div to the middle of an icon
		//the following lines are a standard formula for calculating points on a circle. x = cx + r * cos(a); y = cy + r * sin(a)
		//We have made adjustments because the center of the circle is not at (0,0), but rather the top/left coordinates for the center of the div
		//We also adjust for the fact that we need to know the coordinates for the top-left corner of the image, not for the center of the image.
		const tmpTop = ((divCircle.height() / 2) + radius * Math.sin(start)) - ($(this).height() / 2);
		const tmpLeft = ((divCircle.width() / 2) + radius * Math.cos(start)) - ($(this).width() / 2);
		start += step; //add the "step" number of radians to jump to the next icon

		//set the top/left settings for the image
		$(this).css("top",tmpTop);
		$(this).css("left",tmpLeft);
	});

});

//Click on big avatar, show small avatars
$('.avatarList').click(function() {
	$(this).toggleClass('expand');
	$('#divCircle').toggleClass('expand');
});

//Click on small avatar
$('#divCircle img').click(function() {
	//Get the attributes form the clicked avatar
	const theSrc = $(this).attr('src');

	//Change big avatar to clicked one
	$('.mainImg img').attr('src',  theSrc);

	let avatarImg;
	const baseUrl = window.location.origin;
	let checkUrl;

	//Choose baseUrl and slice wanted piece of url of image
	if(baseUrl === 'http://localhost:8888') {
		//Slice string from character 29 to end
		avatarImg = theSrc.slice(29);
		checkUrl = 'http://localhost:8888/a19ux5/index.php/Controller/editAccount';
	}
	else if (baseUrl === 'http://localhost') {
		avatarImg = theSrc.slice(24);
		checkUrl = 'http://localhost/a19ux5/index.php/Controller/editAccount';
	}
	else {
		avatarImg = theSrc.slice(32);
		checkUrl = 'http://a19ux5.studev.groept.be/index.php/Controller/editAccount';
	}
	console.log("avatarImg: "+avatarImg);
	console.log("checkUrl: "+checkUrl);

	let urlAvatar;
	//Check which page you are on to select controller function for the ajax
	if(document.body.id === "editAccountFunction") {
		urlAvatar = '../Controller/editAccountFunction';
	}
	else {
		urlAvatar = '../Controller/signup';
	}
	console.log("urlAvatar: "+urlAvatar);

	//Post selected avatarImg to controller function
	$.ajax({
		type: 'POST',
		url: urlAvatar,
		data: {avatar_temp: avatarImg}
	});
});

