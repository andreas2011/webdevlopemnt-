function readOutLoud() {
	if(busy === 0){
		turnOnTomGif();
		if('speechSynthesis' in window){
			let  msg = new SpeechSynthesisUtterance(tomText);
			msg.lang = 'nl-NL';
			msg.rate = 0.7;
			msg.addEventListener('end', function (event) {
				turnOffTomGif();
			});
			window.speechSynthesis.speak(msg);
		}

	}
}
function turnOnTomGif() {
	tom.src = gif;
	busy = 1;
}
function turnOffTomGif() {
	window.speechSynthesis.cancel();
	tom.src = pic;
	busy = 0;
}
