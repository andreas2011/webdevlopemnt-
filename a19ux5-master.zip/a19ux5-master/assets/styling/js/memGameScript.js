// Using code from https://www.taniarascia.com/how-to-create-a-memory-game-super-mario-with-plain-javascript/

'use strict';

let gameGrid = null;

//Check if new game or not
if(localStorage.getItem('page') === 'otherPage') {
	//Get stored gameGrid
	gameGrid = JSON.parse(localStorage.getItem('gameGrid'));
}

else {
	//Make array of cards
	const cardsArray = [
		{
			name: 'lion',
			img: '../../assets/images/memory_game/card_lion.png',
			hidden: 'false',
		},
		{
			name: 'giraffe',
			img: '../../assets/images/memory_game/card_giraffe.png',
			hidden: 'false',
		},
		{
			name: 'wolf',
			img: '../../assets/images/memory_game/card_wolf.png',
			hidden: 'false',
		},
		{
			name: 'leopard',
			img: '../../assets/images/memory_game/card_leopard.png',
			hidden: 'false',
		},
		{
			name: 'zebra',
			img: '../../assets/images/memory_game/card_zebra.png',
			hidden: 'false',
		},
		{
			name: 'rhino',
			img: '../../assets/images/memory_game/card_rhino.png',
			hidden: 'false',
		},
	];

	//Duplicate & randomise the cards
	gameGrid = cardsArray.concat(cardsArray).sort(function () {
		return 0.5 - Math.random();
	});

	let progress = 1;
	localStorage.setItem('progress', progress);
}

//Initialise variables
let firstGuess = '';
let secondGuess = '';
let count = 0;
let previousTarget = null;
let delay = 1200;
let longDelay = 2000;

//Get the game div from document
const game = document.getElementById('game');
//Create grid section in document
const grid = document.createElement('section');
//Add class grid to it
grid.setAttribute('class', 'grid');
//Append it to the game div
game.appendChild(grid);

//Loop through all the items in the gameGrid
gameGrid.forEach(function (item) {
	//Get the name & img from the item
	const name = item.name,
		img = item.img;

	//Create the card div
	const card = document.createElement('div');
	card.classList.add('card_mem');
	card.dataset.name = name;

	//Create the front div of the card & class front
	const front = document.createElement('div');
	front.classList.add('front');

	//Create the back div of the card & class back
	const back = document.createElement('div');
	back.classList.add('back');
	//Add the image
	back.style.backgroundImage = 'url(' + img + ')';

	//If the cards are hidden, add class match
	if(item.hidden === 'true') {
		card.classList.add('match');
	}

	//Append the cards & its front and back
	grid.appendChild(card);
	card.appendChild(front);
	card.appendChild(back);
});

//Loop through cards & add class match to selected ones
const match = function match() {
	const selected = document.querySelectorAll('.selected');
	selected.forEach(function (card) {
		card.classList.add('match');
	});
};

//Reset all the guess variables & delete selected class from them
const resetGuesses = function resetGuesses() {
	firstGuess = '';
	secondGuess = '';
	count = 0;
	previousTarget = null;

	const selected = document.querySelectorAll('.selected');
	selected.forEach(function (card) {
		card.classList.remove('selected');
	});
};

//Go to the next page
const nextPage = function nextPage() {

	window.location.href = link;
};

//Check for clicks
grid.addEventListener('click', function (event) {
	//Get target
	const clicked = event.target;

	//Ignore if clicked somewhere other than the cards
	if (clicked.nodeName === 'SECTION' || clicked === previousTarget || clicked.parentNode.classList.contains('selected') || clicked.parentNode.classList.contains('match')) {
		return;
	}

	//When no more cards than 2 are clicked
	if (count < 2) {
		count++;
		if (count === 1) {
			//When first card clicked, add class selected & get name from card (parentNode because it's one div higher)
			firstGuess = clicked.parentNode.dataset.name;
			console.log(firstGuess);
			clicked.parentNode.classList.add('selected');
		} else {
			//When second card clicked, add class selected & get name from card
			secondGuess = clicked.parentNode.dataset.name;
			console.log(secondGuess);
			clicked.parentNode.classList.add('selected');
		}

		//Check if guesses are set
		if (firstGuess && secondGuess) {
			//Check if cards are the same
			if (firstGuess === secondGuess) {
				//Call match function with delay
				setTimeout(match, delay);

				//Loop through all cards and set them hidden if they are part of selected pair
				gameGrid.forEach(function (item) {
					if(item.name === secondGuess) {
						item.hidden = 'true';
					}
				});

				//Save gameGrid for next game step & flag 'otherPage'
				localStorage.setItem('gameGrid', JSON.stringify(gameGrid));
				localStorage.setItem('page','otherPage');

				//Go to next page with longDelay
				setTimeout(nextPage, longDelay);
			}
			//Reset guesses when cards are not the same
			setTimeout(resetGuesses, delay);
		}
		//Set previousTarget to the clicked target
		previousTarget = clicked;
	}
});


