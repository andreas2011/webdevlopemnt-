<?php


class Resident_form_model extends CI_Model
{

	/**
	 * Resident_form_model constructor.
	 */
	public function __construct()
	{
		parent::__construct();
	}

	public function pushFormData($resident=NULL) {
		$this->db->insert('a19ux5.resident', $resident);
		return $this->db->insert_id();
	}

	public function getFormData($idResident) {
		//$query = $this->db->query("select name, firstname, birthyear, roomnr, active, gender from a19ux5.resident where idresident = '$idResident';");
		$this->db->where('idresident', $idResident)->select('name, firstname, birthyear, roomnr, active, gender')->from('a19ux5.resident');
		$query = $this->db->get();

		foreach ($query->result() as $row)
		{
			return $row;
		}
	}

	public function updateFormData($resident=NULL, $idResident=NULL) {
		$this->db->where('idresident', $idResident);
		$this->db->update('a19ux5.resident', $resident);
	}

	public function saveSignature($url, $idResident) {
		//$this->db->query("update a19ux5.resident set signature = '$url' where idresident = '$idResident'");
		$this->db->set('signature', $url);
		$this->db->where('idresident', $idResident);
		$this->db->update('a19ux5.resident');
	}

	public function getIfSignatureSet($idResident) {
		//$sql = "select signature from a19ux5.resident where idresident = '$idResident';";
		$this->db->where('idresident', $idResident)->select('signature')->from('a19ux5.resident');
		//$query = $this->db->query($sql);
		$query = $this->db->get();
		$signature = $query->row()->signature;
		$signatureSet = 1;

		if($signature == NULL) {
			$signatureSet = 0;
		}

		return $signatureSet;
	}
}
