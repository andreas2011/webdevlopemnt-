<?php


class database_model extends CI_Model
{

	public function get_name($userid){
		$query = $this->db->query("SELECT idcaregiver, r.name as resname, c.name as lastname, c.firstname as firstname, c.adminfunction as adminfunction FROM a19ux5.caregiver c inner join department d on c.iddepartment = d.iddepartment inner join residency r on d.idresidency = r.idresidency where idcaregiver=$userid;");
		$row = $query->row_array();
		if (isset($row))
		{
			$name = $row['firstname'] . " " . $row['lastname'];
			$caregiverinfo = array(
				'name' => $name,
				'firstname' => $row['firstname'],
				'adminFunction' => $row['adminfunction'],
				'nh' => $row['resname']
			);
			return $caregiverinfo;
		}
		else
			return "error";
	}


	/*---------- FUNCTIONS FOR THE SURVEY QUESTIONS + SIGNATURE ---------- */


	public function get_question_data()
	{
		return $this->get_q($_SESSION['idQu']);
	}

	public function get_next_question_data()
	{
		return $this->get_q($_SESSION['idQu']+1);
	}

	public function get_q($questionid){
		$sql = "SELECT idquestion, question,category,category_id FROM a19ux5.question;";
		$stmt = $this->db->conn_id->prepare($sql);
		$stmt->execute();
		foreach ($stmt->fetchAll() as $row) {

			if($questionid == $row['idquestion'])
			{
				$question = $row['question'];
				$category = $row['category'];
				$categoryid = $row['category_id'];

				$sqltotal = "SELECT count(*) as totalNumber FROM a19ux5.question  WHERE category = :category;";
				$stmt = $this->db->conn_id->prepare($sqltotal);
				$stmt->bindParam(':category', $category, PDO::PARAM_STR);
				$stmt->execute();
				foreach ($stmt->fetchAll() as $total){
					$Number = $total['totalNumber'];
					$q = array(
						'question' => $question,
						'category' => $category,
						'number'=>$Number,
						'categoryid'=>$categoryid
					);
					return $q;

				}
			}
		}
	}


	public function get_previous_question_answer()
	{
		$this->get_curOrPrev_q_answer($_SESSION['idQu']-1);
	}

	public function get_current_question_answer()
	{
		$this->get_curOrPrev_q_answer($_SESSION['idQu']);
	}

	public function get_curOrPrev_q_answer($questionid){
		$surveyid=$this->getsurveyid();
		$sql = "SELECT answer FROM a19ux5.answer WHERE idsurvey=:surveyid AND idquestion=:questionid ;";
		$stmt = $this->db->conn_id->prepare($sql);
		$stmt->bindParam(':surveyid', $surveyid, PDO::PARAM_INT);
		$stmt->bindParam(':questionid', $questionid, PDO::PARAM_INT);
		$stmt->execute();
		foreach ($stmt->fetchAll() as $row) {

			return $row['answer'];

		}
	}


	public function write_answer($answer)
	{
		$surveyid=$this->getsurveyid();
		$questionid = $_SESSION['idQu'];
		$sqlans = "SELECT * FROM a19ux5.answer WHERE idquestion= :questionid AND idsurvey=:surveyid; ";
		$stmt = $this->db->conn_id->prepare($sqlans);
		$stmt->bindParam(':questionid', $questionid, PDO::PARAM_INT);
		$stmt->bindParam(':surveyid', $surveyid, PDO::PARAM_INT);
		$stmt->execute();

		if($stmt->fetchAll()) {
			$data = array(
					'answer' => $answer,
				);
				$this->db->where('idquestion', $questionid);
			    $this->db->where('idsurvey', $surveyid);
				$this->db->update('answer', $data);

		}
		else
		{

				$data = array(
					'answer' => $answer,
					'idquestion'=>$questionid,
					'idsurvey'=>$surveyid
				);
				$this->db->insert('answer',$data);
		}

	}


	public function newsurvey($anonymous)
	{
		$data = array(
			'idresident' => $_SESSION['residentid'],
			'anon' => $anonymous
		);
		$this->db->insert('survey',$data);
	}

	public function getsurveyid()
	{
		$sql="SELECT * FROM survey WHERE idresident=:id  order by timestamp desc limit 1;";
		$stmt = $this->db->conn_id->prepare($sql);
		$stmt->bindParam(':id', $_SESSION['residentid'], PDO::PARAM_INT);
		//$stmt->bindParam(':an', $anonymous, PDO::PARAM_INT);
		$stmt->execute();

		foreach ($stmt->fetchAll() as $row) {
			$idsurvey = $row['idsurvey'];
			return $idsurvey;
		}

	}

	public function getanon()
	{
		$id=$this->getsurveyid();

		$sql="SELECT anon FROM survey WHERE idresident=:idres and idsurvey=:id;";
		$stmt = $this->db->conn_id->prepare($sql);
		$stmt->bindParam(':idres', $_SESSION['residentid'], PDO::PARAM_INT);
		$stmt->bindParam(':id', $id, PDO::PARAM_INT);
		$stmt->execute();
		foreach ($stmt->fetchAll() as $row) {
			$anon = $row['anon'];
			return $anon;
		}
	}



	public function sign($url)
	{
		$id=$this->getsurveyid();

		$data = array(
			'signature' => $url,
		);
		//$this->db->where('idresident', $_SESSION['residentid']);
		$this->db->where('idsurvey', $id);
		$this->db->update('survey', $data);
	}

	public function firstSign($url)
	{
		$data = array(
			'signature' => $url,
		);
		$userId = $_SESSION['residentid'];
		$this->db->where('idresident', $userId);
		$this->db->update(resident, $data);

	}




	/*---------- FUNCTIONS FOR THE GRAPHS RESULTS ---------- */

	public function get_averages(){
		$sql = "select studyresult.category, avg(answer-0) as average, avg(score) as global 
					from studyresult inner join question q on studyresult.category = q.category 
					inner join answer a on q.idquestion = a.idquestion 
					where not answer like 'weetniet'
					group by q.category;";
		$query = $this->db->query($sql);

		return $query->result();
	}


	public function get_categoryavg($category){
		$sql = "select question, avg(answer-0) as average, avg(score) as global 
					from studyresult_question inner join question q on studyresult_question.idquestion = q.idquestion 
					inner join answer a on q.idquestion = a.idquestion 
					where not answer like 'weetniet' and q.category like'$category'
					group by question;";
		$query = $this->db->query($sql);

		return $query->result();
	}

	public function get_indcategoryavg($category,$residentid){
		$sql = "select question, avg(answer-0) as average, avg(score) as global 
					from studyresult_question inner join question q on studyresult_question.idquestion = q.idquestion 
					inner join answer a on q.idquestion = a.idquestion 
					inner join survey s on a.idsurvey = s.idsurvey
					inner join resident r on s.idresident = r.idresident
					where not answer like 'weetniet' and q.category like'$category' and r.idresident=$residentid
					group by question;";
		$query = $this->db->query($sql);

		return $query->result();
	}

	public function get_individualavg($residentid){
		$sql = "select r.firstname, r.name, studyresult.category, avg(answer-0) as average, avg(score) as global 
					from studyresult inner join question q on studyresult.category = q.category 
					inner join answer a on q.idquestion = a.idquestion 
					inner join survey s on a.idsurvey = s.idsurvey
					inner join resident r on s.idresident = r.idresident
					where not answer like 'weetniet' and r.idresident=$residentid
					group by q.category;";
		$query = $this->db->query($sql);

		return $query->result();
	}

	public function get_stacked($category){
		$sql = "select question, answer, count(answer-0) as nr 
				from question q inner join answer a on q.idquestion = a.idquestion 
				where q.category='$category'
				group by question,answer
				order by question;";
		$printout = $this->get_stackedresults($sql);
		return $printout;
	}

	public function get_stackedindcat($residentid,$category){
		$sql = "select question, answer, count(answer-0) as nr 
				from question q inner join answer a on q.idquestion = a.idquestion 
				inner join survey s on a.idsurvey = s.idsurvey
				inner join resident r on s.idresident = r.idresident
				where q.category='$category' and r.idresident='1'
				group by question,answer
				order by question;";
		$printout = $this->get_stackedresults($sql);
		return $printout;
	}

	public function get_stackedoverview(){
		$sql = "select category, question, answer, count(answer-0) as nr
					from question q inner join answer a on q.idquestion = a.idquestion
					group by question,answer,category
					order by category,question;";
		$printout = $this->get_stackedresults($sql);
		return $printout;
	}


	public function get_stackedresults($sql){

		$query = $this->db->query($sql);

		$question = "";
		$nooit = 0;
		$zelden = 0;
		$soms = 0;
		$meestal = 0;
		$altijd = 0;
		$weetniet = 0;

		$printout = "";
		$firsttime = 1;
		foreach ($query->result_array() as $row)
		{
			if($question == $row["question"]){

			}
			else{
				if($firsttime==1){
					$firsttime=0;
				}
				else{
					$printout.= "['$question', $nooit, $zelden, $soms, $meestal, $altijd,$weetniet],\n";
					$nooit = 0;
					$zelden = 0;
					$soms = 0;
					$meestal = 0;
					$altijd = 0;
					$weetniet = 0;
				}

				$question = $row["question"];

			}

			if($row["answer"]=="nooit"){
				$nooit = $row["nr"];
			}
			else if($row["answer"]=="zelden"){
				$zelden = $row["nr"];
			}
			else if($row["answer"]=="soms"){
				$soms = $row["nr"];
			}
			else if($row["answer"]=="meestal"){
				$meestal = $row["nr"];
			}
			else if($row["answer"]=="altijd"){
				$altijd = $row["nr"];
			}
			else if($row["answer"]=="weetniet"){
				$weetniet = $row["nr"];
			}
		}
		$printout.= "['$question', $nooit, $zelden, $soms, $meestal, $altijd,$weetniet],\n";

		return $printout;
	}



	public function get_timevalues($timeToGroup){
		$sql 	= " select * from resident inner join survey s on resident.idresident = s.idresident inner join answer a on s.idsurvey = a.idsurvey inner join question q on a.idquestion = q.idquestion order by timestamp desc;";
		$sql1 = " SELECT AVG(answer) FROM resident inner join survey s on resident.idresident = s.idresident inner join answer a on s.idsurvey = a.idsurvey inner join question q on a.idquestion = q.idquestion WHERE (timestamp > ";
		return $this->averaging($timeToGroup,$sql,$sql1);
	}

	public function get_timevaluesind($timeToGroup, $residentid){
		$sql 	= " select * from resident 
 					inner join survey s on resident.idresident = s.idresident 
 					inner join answer a on s.idsurvey = a.idsurvey 
 					inner join question q on a.idquestion = q.idquestion 
 					where resident.idresident=$residentid
 					order by timestamp desc;";
		$sql1 = " SELECT AVG(answer) FROM resident 
 					inner join survey s on resident.idresident = s.idresident 
 					inner join answer a on s.idsurvey = a.idsurvey 
 					inner join question q on a.idquestion = q.idquestion 
 					WHERE not answer like 'weetniet' and (resident.idresident=$residentid AND timestamp > ";
		return $this->averaging($timeToGroup,$sql,$sql1);
	}

	public function get_timevaluesindcat($timeToGroup, $residentid, $category){
		$sql 	= " select * from resident 
 					inner join survey s on resident.idresident = s.idresident 
 					inner join answer a on s.idsurvey = a.idsurvey 
 					inner join question q on a.idquestion = q.idquestion 
 					where resident.idresident=$residentid and category = '$category'
 					order by timestamp desc;";
		$sql1 = " SELECT AVG(answer) FROM resident 
 					inner join survey s on resident.idresident = s.idresident 
 					inner join answer a on s.idsurvey = a.idsurvey 
 					inner join question q on a.idquestion = q.idquestion 
 					WHERE (resident.idresident=$residentid and category = '$category' AND timestamp > ";
		return $this->averaging($timeToGroup,$sql,$sql1);
	}

	public function get_timevaluescategory($timeToGroup,$category){
		$sql 	= " select * from resident 
 					inner join survey s on resident.idresident = s.idresident 
 					inner join answer a on s.idsurvey = a.idsurvey 
 					inner join question q on a.idquestion = q.idquestion 
 					where category = '$category' order by timestamp desc;";
		$sql1 = " SELECT AVG(answer) FROM resident 
 					inner join survey s on resident.idresident = s.idresident 
 					inner join answer a on s.idsurvey = a.idsurvey 
 					inner join question q on a.idquestion = q.idquestion 
 					WHERE (category = '$category' AND timestamp > ";
		return $this->averaging($timeToGroup,$sql,$sql1);
	}

	public function averaging($timeToGroup,$sql,$sql_detailed) {

		date_default_timezone_set("Europe/Brussels");

		$datenow =  new DateTime('now');
		$count = 0;


		$dategrouped = $datenow;

		$printstring = "";

//		$sql 	= " select * from resident inner join survey s on resident.idresident = s.idresident inner join answer a on s.idsurvey = a.idsurvey order by timestamp desc;";

		$query = $this->db->query($sql);

		foreach ($query->result_array() as $row)
		{
			if($count < 10){ //we only want 10 measurements on our graph
				$datefetch =  new DateTime($row["timestamp"]);

				if($dategrouped == $datenow || $datefetch < $dategrouped ){

					$datestringoriginal = $datefetch->format('Y-m-d H:i:s');
					$dategrouped = $datefetch->modify($timeToGroup);
					$datestring = $datefetch->format('Y-m-d H:i:s');

//					$sql1 = " SELECT AVG(answer) FROM resident inner join survey s on resident.idresident = s.idresident inner join answer a on s.idsurvey = a.idsurvey WHERE timestamp > '$datestring';";
					$sql1 = $sql_detailed."'$datestring');";
					$query1 = $this->db->query($sql1);
					foreach ($query1->result_array() as $row1)
					{
//						echo "[";   echo "'";
						$printstring = $printstring."['".$this->timeprint($datestring, $datestringoriginal)."', ". round($row1["AVG(answer)"], 2). "],";
//						$timeprint[$count] = $this->timeprint($datestring, $datestringoriginal);
//						echo "'";   echo ", ". round($row1["AVG(answer)"], 2). "],";
//						$avgscore[$count] = round($row1["AVG(answer)"], 2);
						$count += 1;
					}
				}
			}
		}


		return $printstring;

	}

	public function timeprint($date1, $date2){

		$array1 = str_split($date1);
		$year1 = $array1[0].$array1[1].$array1[2].$array1[3];
		$month1 = $array1[5].$array1[6];
		$day1 = $array1[8].$array1[9];

		$hour1 = $array1[11].$array1[12];
		$minute1 = $array1[14].$array1[15];
		$sec1 = $array1[17].$array1[18];

		$array2 = str_split($date2);
		$year2 = $array2[0].$array2[1].$array2[2].$array2[3];
		$month2 = $array2[5].$array2[6];
		$day2 = $array2[8].$array2[9];

		$hour2 = $array2[11].$array2[12];
		$minute2 = $array2[14].$array2[15];
		$sec2 = $array2[17].$array2[18];

		$months[0] = "";
		$months[1] = "jan";
		$months[2] = "feb";
		$months[3] = "mar";
		$months[4] = "apr";
		$months[5] = "may";
		$months[6] = "jun";
		$months[7] = "jul";
		$months[8] = "aug";
		$months[9] = "sep";
		$months[10] = "oct";
		$months[11] = "nov";
		$months[12] = "dec";



		$finalprint = "";
//		if( $day1==$day2){
//			$finalprint .= "".$day1."-";
//		}
//		else{
//			$finalprint .= "[".$day1."/".$day2."]-";
//		}
//		if( $month1==$month2){
//			$finalprint .= "".$months[(int)$month1]."-";
//		}
//		else{
//			$finalprint .= "[".$months[(int)$month1]."/".$months[(int)$month2]."]-";
//		}
//		if( $year1==$year2){
//			$finalprint .= "".$year1." ";
//		}
//		else{
//			$finalprint .= "[".$year1."/".$year2."] ";
//		}
		if($year1==$year2){
			$finalprint .= "(".$months[(int)$month1]."-".$months[(int)$month2].") ".$year1."";
		}
		else{
			$finalprint .= "[".$months[(int)$month1]."/".$year1."]-[".$months[(int)$month2]."/".$year2."]";
		}




//		if( $year1==$year2 && $month1==$month2){
//			if( !($hour1==$hour2 && $day1!=$day2)){ //!(days different, hours the same --> grouped by days)
//				if( $hour1==$hour2){
//					$finalprint .= "".$hour1.":";
//				}
//				else{
//					$finalprint .= "[".$hour1."/".$hour2."]:";
//				}
//				if( $minute1==$minute2){
//					$finalprint .= "".$minute1."";
//				}
//				else{
//					$finalprint .= "[".$minute1."/".$minute2."]";
//				}
//				//             if( $sec1==$sec2){
//				//                 $finalprint .= "".$sec1."";
//				//             }
//				//             else{
//				//                 $finalprint .= "[".$sec1."/".$sec2."]";
//				//             }
//			}
//		}
//		echo $finalprint;
		return $finalprint;
	}


	/* -------------- FUNCTION LOTTERY ---------- */

	public function getWinner($timerange) {

		date_default_timezone_set("Europe/Brussels");

		$datenow =  new DateTime('now');
		$datetimerange = $datenow->modify($timerange);
		$datestring = $datetimerange->format('Y-m-d H:i:s');

		$sql = "select distinct name,firstname from resident inner join survey s on resident.idresident = s.idresident where timestamp> '$datestring' ORDER BY RAND ()  LIMIT 1";

		$query = $this->db->query($sql);

		$results="";

		foreach ($query->result_array() as $row)
		{
			$results.= $row['firstname']." ".$row['name'];
		}

		return $results;


	}






}
