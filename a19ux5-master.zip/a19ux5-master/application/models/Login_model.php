<?php


class Login_model extends CI_Model
{


	/**
	 * login_model constructor.
	 */
	public function __construct()
	{
		parent::__construct();
	}

	public function loginuser($logindetails=NULL) {

		if($logindetails!=NULL) {
			$username = $logindetails['username'];
			$password = $logindetails['password'];
		}
		else{
			echo"POST method went wrong!";
		}

		$pass_incorrect=0;
		$user_no_exist=0;
		if ( isset( $_SESSION['/user_id'] ) ) {
			//	header("Location: https://a19ux5.studev.groept.be/");
		}
		else {
			//$sql = "SELECT * FROM caregiver WHERE username = ?;";
			//$query = $this->db->query($sql, array($username));
			$this->db->where('username', $username)->select('*')->from('a19ux5.caregiver');
			$query = $this->db->get();

			$row = $query->row();



			if (isset($row))
			{
				//user found with that username
				$_SESSION['avatar'] = $row->avatar;
			}
			else{
				//echo"no user found with that username<br>";
				$user_no_exist=1;
			}

			if($user_no_exist==0){
			// Verify user password and set $_SESSION

			if ( password_verify( $password, $row->password ) ) {
				$_SESSION['user_id'] = $row->idcaregiver;
				header("Location: ./home");
			} else{
				$pass_incorrect=1;
			}
			}
		}

		$errors = array(
			'user_no_exist' => $user_no_exist,
			'pass_incorrect' => $pass_incorrect,
		);

		return $errors;
	}

	public function forgotpassword($email=NULL) {
		$email_exists = 1;
		if($email==NULL){
			echo "something went wrong with the post!";
		}
		//echo $email;

		//$sql = "SELECT * FROM caregiver WHERE email = ?;";
		//$query = $this->db->query($sql, array($email));
		$this->db->where('email', $email)->select('*')->from('a19ux5.caregiver');
		$query = $this->db->get();

		$row = $query->row();

		if (isset($row))
		{
			//email found

			//generate a new password
			$password = rand(999, 99999);
			$hash = password_hash($password, PASSWORD_DEFAULT);

			$data = array(
				'password' => $hash
			);

			$this->db->where('email', $email);
			$this->db->update('caregiver', $data);


			$firstname = $row->firstname;


			//send mail
			$to      = $email;
			$subject = 'CareHome | new password';
			$message = 'Hello '.$firstname.',' . "\r\n" . "\r\n" .
				'This mail contains the new password for your account on CareHome. If it was not you who requested a new password, ignore this mail.' ."\r\n" . "\r\n" .
				'your new password is: ' . $password . '. You can log in via our website (https://a19ux5.studev.groept.be/). You can no longer log in with your old password.'.
				' We recommend to change your password as soon as possible.' . "\r\n" . "\r\n" .
				'Kind regards,' . "\r\n" . "\r\n" . 'UXWD5';
			$headers = 'From: UXWD5' . "\r\n" .
				'Reply-To: noreply@mailinator.com' . "\r\n" .
				'X-Mailer: PHP/' . phpversion();

			//echo $message;

			mail($to, $subject, $message, $headers);

			//header("Location: ./login.php");
		}
		else{
			$email_exists = 0;
		}

		return $email_exists;


	}

	public function signupusers($data){

		$username_exists = 0;
		$successful = 0;

		if($data!=NULL) {
			$username = $data['username'];
			$password = $data['password'];
			$firstname = $data['firstname'];
			$lastname = $data['lastname'];
			$email = $data['email'];
			$admin = $data['admin'];
			$iddepartment = $data['iddepartment'];
			$avatar = $data['avatar'];
		}
		else{
			echo"POST method went wrong!";
		}

//		echo "uname: " . $username . "<br>pw: " . $password . "<br>firstname: " . $firstname . "<br>lastname: " . $lastname . "<br>email: " . $email;
//		echo "<br>admin: " . $admin . " <br><br>";


		//Check if a username already exists
		//$sql = "SELECT * FROM caregiver WHERE username = ?";
		//$query = $this->db->query($sql, array($username));
		$this->db->where('username', $username)->select('*')->from('a19ux5.caregiver');
		$query = $this->db->get();

		$row = $query->row();

		if (isset($row))
		{
//			echo "username already exists";
			$username_exists = 1;
		}
		else{
			//insert user if username doesn't already exists
			$hash = password_hash($password, PASSWORD_DEFAULT);
			$data = array(
				'name' => $lastname,
				'firstname' => $firstname,
				'username' => $username,
				'password' => $hash,
				'iddepartment' => $iddepartment,
				'adminfunction' => $admin,
				'email' => $email,
				'avatar' => $avatar
			);

			$this->db->insert('caregiver', $data);
//			echo "<br><b>New user created successfully</b>";
			$successful = 1;
		}


		$errors = array(
			'username_exists' => $username_exists,
			'successful' => $successful,
		);

		return $errors;


	}

	//needed for editAccountFunction (to show all account details to edit it)
	public function getAccountData($idUser) {
		//$query = $this->db->query("select name, firstname, username, password, adminfunction, email, avatar from a19ux5.caregiver where idcaregiver = '$idUser';");
		$this->db->where('idcaregiver', $idUser)->select('name, firstname, username, password, adminfunction, email, avatar')->from('a19ux5.caregiver');
		$query = $this->db->get();

		foreach ($query->result() as $row)
		{
			return $row;
		}
	}

	public function updateAccountData($data) {
		$username_exists = 0;
		$successful = 0;

		if($data!=NULL) {
			$username = $data['username'];
		}
		else{
			echo"POST method went wrong!";
		}

		//Check if a username already exists
		//$sql = "SELECT * FROM caregiver WHERE username = ?";
		//$query = $this->db->query($sql, array($username));
		$this->db->where('username', $username)->select('*')->from('a19ux5.caregiver');
		$query = $this->db->get();

		$row = $query->row();

		if (isset($row) && $_SESSION['username'] != $username) {
			//username already exists
			$username_exists = 1;
		}
		else {
			//update user if new username doesn't already exists except if it is the old one
			$this->db->where('idcaregiver', $_SESSION['user_id']);
			$this->db->update('a19ux5.caregiver', $data);
			$successful = 1;
		}

		$errors = array(
			'username_exists' => $username_exists,
			'successful' => $successful,
		);

		return $errors;
	}

	public function updateAccountPassword($newPassword) {
		$caregiverId = $_SESSION['user_id'];
		$hash = password_hash($newPassword, PASSWORD_DEFAULT);
		//$sql = "update a19ux5.caregiver set password = '$hash' where idcaregiver = '$caregiverId';";
		//$this->db->query($sql);
		$this->db->set('password', $hash);
		$this->db->where('idcaregiver', $caregiverId);
		$this->db->update('a19ux5.caregiver');
	}

	public function checkAccountPassword($oldPassword) {
		$passwordCorrect = 0;
		$caregiverId = $_SESSION['user_id'];
		//$sql = "select password from a19ux5.caregiver where idcaregiver = '$caregiverId';";
		//$query = $this->db->query($sql);
		$this->db->where('idcaregiver', $caregiverId)->select('password')->from('a19ux5.caregiver');
		$query = $this->db->get();

		$passwordDB = $query->row()->password;

		if (password_verify($oldPassword, $passwordDB)) {
			$passwordCorrect = 1;
		}

		return $passwordCorrect;
	}
}
