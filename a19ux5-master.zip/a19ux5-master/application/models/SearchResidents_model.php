<?php


class SearchResidents_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}

	public function fillTable($searchquery, $isEdit, $isChecked,$isSignatureChecked)
	{
		$q = $this->db->escape_like_str($searchquery);
		$url = base_url();
		if($isEdit == 1){
			if($isSignatureChecked == 1){
				$sql = "SELECT resident.idresident, resident.firstname, resident.name, resident.roomnr, resident.signature, MAX(survey.timestamp) as latest
				FROM a19ux5.resident
				LEFT JOIN  a19ux5.survey
				ON resident.idresident = survey.idresident
				WHERE (resident.firstname LIKE '$q%' OR resident.name LIKE '$q%' OR resident.roomnr LIKE'$q%') AND (resident.signature IS NULL)
				GROUP BY resident.idresident
				ORDER BY resident.firstname";
			}
			else if ($isSignatureChecked==0){
				if($isChecked == 1){
					$sql = "SELECT resident.idresident, resident.firstname, resident.name, resident.roomnr, MAX(survey.timestamp) as latest
				FROM a19ux5.resident
				LEFT JOIN  a19ux5.survey
				ON resident.idresident = survey.idresident
				WHERE (resident.firstname LIKE '$q%' OR resident.name LIKE '$q%' OR resident.roomnr LIKE'$q%') AND (resident.active = 0)
				GROUP BY resident.idresident
				ORDER BY resident.firstname";
				}
				else if($isChecked == 0){
					$sql = "SELECT resident.idresident, resident.firstname, resident.name, resident.roomnr, MAX(survey.timestamp) as latest
				FROM a19ux5.resident
				LEFT JOIN  a19ux5.survey
				ON resident.idresident = survey.idresident
				WHERE (resident.firstname LIKE '$q%' OR resident.name LIKE '$q%' OR resident.roomnr LIKE'$q%') AND (resident.active = 1)
				GROUP BY resident.idresident
				ORDER BY resident.firstname";
				}
			}
			$img = ")\" class=\"btn btn-sm primary-color-inverted\"><img src=\"" . $url . "assets/icons/083-edit_blue.svg\" class=\"primary-color-inverted\" alt=\"\" height=\"30\" width=\"auto\">";
		}
		else if($isEdit == 0){
			$sql = "SELECT resident.idresident, resident.firstname, resident.name, resident.roomnr, MAX(survey.timestamp) as latest
				FROM a19ux5.resident
				LEFT JOIN  a19ux5.survey
				ON resident.idresident = survey.idresident
				WHERE (resident.firstname LIKE '$q%' OR resident.name LIKE '$q%' OR resident.roomnr LIKE'$q%') AND (resident.active = 1)
				GROUP BY resident.idresident
				ORDER BY latest, resident.firstname";
			$img = ")\" class=\"btn btn-sm secondary-color-inverted\"><img src=\"" . $url . "assets/icons/right-arrow-blue.svg\" class=\"secondary-color-inverted\" alt=\"\" height=\"30\" width=\"auto\">";
		}

		$query = $this->db->query($sql);


		$results = $query->result_array();
		$content = "";

		foreach ($results as $row) {
			if($row['latest'] == null){
				$row['latest'] = "N.V.T.";
			}
			else{
				$row['latest'] = substr($row['latest'], 0, 10);
			}

			$content .= "<tr>
						<td><h5>" . $row['firstname'] . " " . $row['name'] . "</h5></td>
						<td><h5>" . $row['roomnr'] . "</h5></td>
						<td><h5>" . substr($row['latest'], 0, 10) . "</h5></td>
						<td><button onclick=\"changeSelectedResident(" . $row['idresident'] . "" . $img. "</button></td>
						</tr>";
		}
		echo $content;
	}

	public function fillTableNonAnon($searchquery)
	{
		$url = base_url();

		$q = $this->db->escape_like_str($searchquery);
		$sql = "SELECT resident.idresident, resident.firstname, resident.name, resident.roomnr, MAX(survey.timestamp) as latest
			FROM a19ux5.resident
			INNER JOIN  a19ux5.survey
			ON resident.idresident = survey.idresident
			WHERE (resident.firstname LIKE '$q%' OR resident.name LIKE '$q%' OR resident.roomnr LIKE'$q%') AND survey.anon = 1
			GROUP BY resident.idresident
			ORDER BY latest, resident.firstname";
		$img = ")\" class=\"btn btn-sm primary-color-inverted\"><img src=\"" . $url . "assets/icons/right-arrow-orange.svg\" class=\"primary-color-inverted\" alt=\"\" height=\"30\" width=\"auto\">";


		$query = $this->db->query($sql);


		$results = $query->result_array();
		$content = "";

		foreach ($results as $row) {
			//$id = $row['idresident'];

			$content .= "<tr>
						<td><h5>" . $row['firstname'] . " " . $row['name'] . "</h5></td>
						<td><h5>" . $row['roomnr'] . "</h5></td>
						<td><h5>" . substr($row['latest'], 0, 10) . "</h5></td>
						<td><button onclick=\"changeSelectedResident(" . $row['idresident'] . "" . $img. "</button></td>
						</tr>";
		}
		echo $content;
	}

	public function getResidentName($resid){
//		$sql = "SELECT resident.firstname, resident.name FROM a19ux5.resident WHERE resident.idresident = $resid;";

//		$query = $this->db->query($sql);
		$query = $this->db->select("resident.firstname, resident.name")->from("a19ux5.resident")->where("resident.idresident",$resid)->get();
		$results = $query->row();
		return $results;
	}


}
