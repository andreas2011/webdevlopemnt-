
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="urf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta http-equiv="X-UA-Compatible" content="ie=edge" />

	<title>{pagetitle}</title>

	<!-- Use Tom as icon of the web tab -->
	<link rel="icon" type="image/png" href="<?php echo base_url() ?>assets/images/tom_32_32px.png" sizes="32x32" />

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<!-- Our CSS -->
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/styling/css/memory_game.css?<?php echo time(); ?>" />
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/styling/css/general_style.css?<?php echo time(); ?>" />
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/styling/css/survey_style.css?<?php echo time(); ?>" />

</head>

<body class="body_mem">
<div class="flex-row top-margin" style="display: inline-flex; justify-content: space-evenly; align-items: center">
	<div class="text-bubble-size info-memgame btn-sq-lg">
		<p class="top-padding left-padding"> {tom_text_memory} </p>
	</div>

<!--	href="{link}"-->
	<a href="{link}">
	<button class="btn btn_choice primary-color-inverted btn-sq-lg" onclick="autoincrease()" >
		<p class="text_button top-padding">{nextbtnname}</p>
		<img src="<?php echo base_url() ?>assets/icons/{nextbtnicon}" alt="Next" class="icon_orange icon_survey" style="padding-bottom: 10px">
	</button>
	</a>
</div>

<div id="game" class="top-margin"></div>

<script>
    let link = "{link}";
     function autoincrease() {
         <?php

        if($_SESSION['finish']<=9)
		{
			$_SESSION['finish']=$_SESSION['finish']+2;
		}
        else
		{
			$_SESSION['finish']=10;
		}

         $_SESSION['count']=$_SESSION['count']+1;//1
         $_SESSION['idQu']=$_SESSION['idQu']+1;//1?>

	 }

</script>


<script src="{memGameScript}"></script>

</body>
</html>
