<head>
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/styling/css/avatar_select.css" />
</head>

<body id="{linkCheckById}">
<!-- Main -->
<main class="main-selectResident">

	<div class="container-fluid">
		<div class="row">
			<div class="col-4"></div>
			<div class="col-6">
				<h1>{title_h1}</h1>
			</div>
			<div class="col-2"></div>
		</div>

		<div class="row">
			<div class="col-4"></div>
			<div class="col-4">
				<div class="alert alert-{alertfct}" role="alert">
					{warningmessage}
				</div>
			</div>
			<div class="col-4"></div>
		</div>

		<div class="row">
			<div class="col-5"></div>
			<div class="col-5">
				<div class="avatarList ml-5">
					<div class="mainImg"><img src={accountAvatar}></div>

					<div id="divCircle">
						<div id="middleBubble"></div>
						<img id="Image1" src="<?php echo base_url() ?>assets/icons/003-male-2.svg">
						<img id="Image2" src="<?php echo base_url() ?>assets/icons/024-male-10.svg">
						<img id="Image3" src="<?php echo base_url() ?>assets/icons/007-male-4.svg">
						<img id="Image4" src="<?php echo base_url() ?>assets/icons/018-female-10.svg">
						<img id="Image5" src="<?php echo base_url() ?>assets/icons/013-female-6.svg">
						<img id="Image6" src="<?php echo base_url() ?>assets/icons/017-female-9.svg">
						<img id="Image7" src="<?php echo base_url() ?>assets/icons/009-female-3.svg">
					</div>
				</div>
			</div>
			<div class="col-2"></div>
		</div>

		<div class="row">
			<div class="col-4"></div>
			<div class="col-6">
				<p>{avatar_text}</p>
			</div>
			<div class="col-2"></div>
		</div>

		<div class="mb-lg-5 row">
			<div class="col-4"></div>
			<div class="col-4">
				<form role="form" action="{formactionLink}" method="post">
					<div class="form-group">
						<input type="text" class="form-control mb-2" name="firstname" placeholder="{first_name}" required>
					</div>
					<div class="form-group">
						<input type="text" class="form-control mb-2" name="lastname" placeholder="{last_name}" required>
					</div>
					<div class="form-group">
						<input type="text" class="form-control mb-2" name="username" placeholder="{username}" required>
					</div>
					<div class="form-group">
						<input type="email" class="form-control mb-2" name="email" placeholder="{email}" required>
					</div>
					<div class="form-group">
						<input type="password" class="form-control mb-2" name="password" placeholder="{password}" required>
					</div>
					<div class="form-check">
						<input type="checkbox" name="admin" class="form-check-input" id="myCheckAdmin" onclick="showAdminFunction()">
						<label class="form-check-label" for="myCheckAdmin">{administrator_check}</label>
						<p id="textAdmin" style="display:none; font-style: italic;">{admincheck_explanation}</p>
					</div>

					<div class="mt-3 mb-5">
						<a class="btn btn-lg primary-color-inverted monitored-btn" href="home" title="{cancelBtnTitle}">{btn_cancel}</a>
						<button type="submit" id="submitButton" class="btn btn-lg primary-color monitored-btn" title="{addBtnTitle}">{btn_new_user}</button>
					</div>
				</form>
			</div>
			<div class="col-4"></div>
		</div>
	</div>
</main>


<script>
    function showAdminFunction() {
        // Get the checkbox
        const checkBox = document.getElementById("myCheckAdmin");
        // Get the output text
        const text = document.getElementById("textAdmin");

        // If the checkbox is checked, display the output text
        if (checkBox.checked == true){
            text.style.display = "block";
        } else {
            text.style.display = "none";
        }
    }
</script>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<!-- To make sure every field is filled in (https://codereview.stackexchange.com/questions/148072/disable-button-when-required-inputs-are-not-filled-in) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<!-- Script for the avatar selector -->
<script src="<?php echo base_url() ?>assets/styling/js/avatarSelectScript.js"></script>

</body>
</html>
