<body class="background-color">
<!-- Header -->
	<main id="main-home">
		<ul id="flex-container-home">
			<li>
				<button onclick="window.location.href = 'addResident';" class="btn primary-color primary-hover w3-padding-large-button w3-margin btn-home">
					<span class="btn-text">{btn_resident}</span>
					<br><br>
					<img src="<?php echo base_url() ?>assets/icons/group-res.svg" alt="" height="200px" width="200px" class="img-home">
				</button>
			</li>
			<li>
				<button onclick="window.location.href = 'signup';" class="btn primary-color primary-hover w3-padding-large-button w3-margin btn-home">
					<span class="btn-text">{btn_user}</span>
					<br><br>
					<img src="<?php echo base_url() ?>assets/icons/user-cg.svg" alt="" height="200px" width="200px" class="img-home icon_white">
				</button>
			</li>
		</ul>
	</main>

<script>
    function addBorder() {
        document.getElementById("addUser").style.borderBottom = "4px solid white";
        switch("<?php echo $this->session->userdata('site_lang')?>") {
            case "english":
                document.getElementById("dropdownButton").innerHTML = '<img src="<?php echo base_url() ?>assets/icons/077-english.svg" alt="" height="25px" width="auto"> English';
                break;
            case "dutch":
                document.getElementById("dropdownButton").innerHTML = '<img src="<?php echo base_url() ?>assets/icons/076-dutch.svg" alt="" height="25px" width="auto"> Nederlands';
                break;
        }
    }

    window.onload = addBorder();
</script>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>
