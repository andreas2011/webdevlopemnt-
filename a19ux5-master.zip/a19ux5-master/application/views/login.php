<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>{page_title}</title>

	<!-- Use Tom as icon of the web tab -->
	<link rel="icon" type="image/png" href="<?php echo base_url()?>assets/images/tom_32_32px.png" sizes="32x32" />

	<link rel="stylesheet" href="<?php echo base_url()?>assets/styling/css/login.css">

	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</head>

<body>



<div class="container">
	<div class="row">
		<div class="col-md-5 mx-auto">
			<div id="first">
				<div class="myform form ">
					<div class="logo mb-3">
						<div class="col-md-12 text-center">
							<h1>Login iCare</h1>
							<div class="alert alert-{alertfct}" role="alert">
								{warningmessage}
							</div>
						</div>
					</div>
					<form action="login" method="post" name="login">
						<div class="form-group">
							<label for="exampleInputEmail1">Username</label>
							<input type="text" class="form-control" aria-describedby="emailHelp" id="username" placeholder="Enter Username" name="username" required>
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">Password</label>
							<input type="password" id="password" class="form-control" aria-describedby="emailHelp" placeholder="Enter Password" name="password" required>
							<div class="col-md-12 text-center ">
								&nbsp;
							</div>
							<button type="submit" class=" btn btn-block mybtn  tx-tfm w3-margin-top">Login</button>
						</div>
						<div class="form-group">
<!--							<p class="text-center">By signing up you accept our <a href="#">Terms Of Use</a></p>-->
						</div>

						<div class="col-md-12 ">
							<div class="login-or">
								<hr class="hr-or">
								<span class="span-or">or</span>
							</div>
						</div>

						<div class="form-group">
							<p class="text-center">Forgot <a href="forgottenpw">password?</a></p>
						</div>
					</form>

				</div>
			</div>
		</div>
	</div>
</div>

</body>

</html>
