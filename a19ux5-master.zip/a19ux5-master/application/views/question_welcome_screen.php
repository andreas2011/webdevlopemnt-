<!DOCTYPE HTML>
<html>
<head>
	<title>{pagetitle}</title>

	<!-- Use Tom as icon of the web tab -->
	<link rel="icon" type="image/png" href="<?php echo base_url() ?>assets/images/tom_32_32px.png" sizes="32x32" />

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	<script src="<?php echo base_url() ?>assets/styling/js/jquery-ui.min.js"></script>
	<script src="<?php echo base_url() ?>assets/styling/js/jquery.validate.js"></script>

	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<!-- Our CSS -->
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/styling/css/general_style.css?<?php echo time(); ?>">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/styling/css/survey_style.css?<?php echo time(); ?>">

</head>
<body style="height: 90%">
	<div class="custom_container">
		<form class="form-horizontal">
			<div class="container extreme-top-margin">

				<div class="row-fluid">
					<br>
					<div class=" flexwelcome" >

						<div class="welcome-bubble sb text-bubble-size" style="margin-right: 10px">
							{tom_text}
						</div>


						<div class="flex-column" style="display: grid; justify-items: center" >
							<img id="tom_id" src="{tom_pic}" alt="Tom de chatbot" class="tom-size">

							<a class="btn text primary-color-inverted btn-listen-width" onclick='readOutLoud()'>
								<div class=" flex-row" style="display: inline-flex">
									<div><p class="text_button top-padding">BELUISTER</p></div>
									<div style="align-self: center; padding-left: 3px;"><img src="<?php echo base_url() ?>assets/icons/055-ear.svg" alt="Question mark" class="icon_small_survey icon_orange"></div>
								</div>
							</a>
						</div>


					</div>

					<div class="form-group">
						<div class="col-sm-12 flex extreme-top-padding">

							<button id="btnModal2" type="button" class="btn btn-welcome secondary-color" onclick="openVideoModal()">
								<p class="text_button top-padding">LEG HET ME UIT</p>
								<img src="<?php echo base_url() ?>assets/icons/075-video-camera.svg" alt="Video" class="icon_survey icon_white img_choice">
							</button>

							<a class="btn btn-welcome secondary-color" onclick="window.location.href='{start_link}'">
								<p class="text_button top-padding">START</p>
								<img src="<?php echo base_url() ?>assets/icons/074-play-button.svg" alt="Start" class="icon_survey icon_white img_choice">
							</a>

						</div>

					</div>

				</div>

			</div>
		</form>
	</div>

	<!-- Tutorial Modal -->
	<div class="modal-menu" id="videoModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog-video modal-lg">
			<div class="modal-content">
				<div class="modal-body-video">
					<button type="button" class="close-video close" data-dismiss="modal" aria-hidden="true" onclick="closeVideoModal()">
						<span aria-hidden="true">&times;</span>
					</button>
					<!-- 16:9 aspect ratio -->
					<div class="embed-responsive embed-responsive-16by9">
						<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/L5W59ZVOyjU" id="video" allowfullscreen="allowfullscreen" allowscriptaccess="always" allow="autoplay"></iframe>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="col-sm-12 flex top-padding bottom-padding progress-bar-location" >
		<button style="padding: 14px 25px;" id="btnModal" type="button" class="btn text primary-color-inverted " onclick="openModal()">
			<img src="<?php echo base_url() ?>assets/icons/stop.svg" alt="Exit" class="icon_survey icon_orange">
		</button>
		<div class="progress"  style="height: 40px;width: 90%" >
			<div class="progress-bar progress-bar-success progress-bar-striped text active" role="progressbar" aria-valuemin="0" aria-valuemax="100"
				 style="background-color: #0072BB ; font-weight:bold; font-size: x-large; width:0.9%" ></div>
		</div>

	</div>


	<script src="<?php echo base_url() ?>assets/styling/js/videoModalScript.js"></script>
	<script src="<?php echo base_url() ?>assets/styling/js/tom.js"></script>
	<script>
		localStorage.removeItem('page');	// Resets memory game
		localStorage.clear('count');
		localStorage.clear('idQu');
		localStorage.clear('anonymous');
	</script>
	<script>
		let busy = 0;
		let tom = document.getElementById('tom_id');
        let tomText = "{tom_text}";
        let pic = "{tom_pic}";
        let gif = "{tom_gif}";
        window.onunload = function () {
            turnOffTomGif();
        }
	</script>

</body>
</html>

