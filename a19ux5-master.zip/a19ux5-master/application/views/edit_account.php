<body id="{linkCheckById}">

<link rel="stylesheet" href="<?php echo base_url() ?>assets/styling/css/avatar_select.css" />

<!-- Main -->
<main class="main-selectResident">

	<div class="container-fluid mb-5">

		<!-- Modal -->
		<div class="modal fade" id="passwordModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="modalLabel">{modalPasswordTitle}</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
						<div class="modal-body">
							<form role="form" action="{modalLink}" method="post">
							<div class="form-group">
								<input type="password" id="oldPassField" class="form-control" name="oldPassword" placeholder="{oldPassword}" required>
							</div>
							<div class="form-group">
								<input type="password" id="newPassField" class="form-control" name="newPassword" placeholder="{newPassword}" required>
							</div>
							<button type="button" class="btn primary-color-inverted monitored-btn" data-dismiss="modal" title="{cancelBtnTitle}">{btn_cancel}</button>
							<button type="submit" id="passwordSubmitBtn" class="btn primary-color monitored-btn" title="{saveBtnTitle}">{btn_edit_account}</button>
							</form>
						</div>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-4"></div>
			<div class="col-6">
				<h1>{title_h1}</h1>
			</div>
			<div class="col-2"></div>
		</div>

		<div class="row">
			<div class="col-4"></div>
			<div class="col-4">
				<div class="alert alert-{alertfct}" role="alert">
					{warningmessage}
				</div>
			</div>
			<div class="col-4"></div>
		</div>

		<div class="row">
			<div class="col-5"></div>
			<div class="col-5">
				<div class="avatarList ml-5">
					<div class="mainImg"><img src={accountAvatar}></div>

					<div id="divCircle">
						<div id="middleBubble"></div>
						<img id="Image1" src="<?php echo base_url(); ?>assets/icons/003-male-2.svg">
						<img id="Image2" src="<?php echo base_url(); ?>assets/icons/024-male-10.svg">
						<img id="Image3" src="<?php echo base_url(); ?>assets/icons/007-male-4.svg">
						<img id="Image4" src="<?php echo base_url(); ?>assets/icons/018-female-10.svg">
						<img id="Image5" src="<?php echo base_url(); ?>assets/icons/013-female-6.svg">
						<img id="Image6" src="<?php echo base_url(); ?>assets/icons/017-female-9.svg">
						<img id="Image7" src="<?php echo base_url(); ?>assets/icons/009-female-3.svg">
					</div>
				</div>
			</div>
			<div class="col-2"></div>
		</div>

		<div class="row">
			<div class="col-4"></div>
			<div class="col-6">
				<p>{avatar_text}</p>
			</div>
			<div class="col-2"></div>
		</div>

		<div class="row">
			<div class="col-4"></div>
			<div class="col-4">
				<form role="form" action="{formactionLink}" method="post">
					<div class="form-group">
						<label for="firstName">{first_name}</label>
						<input type="text" class="form-control" name="firstName" value="{firstNameField}" required>
					</div>
					<div class="form-group">
						<label for="lastName">{last_name}</label>
						<input type="text" class="form-control" name="lastName" value="{lastNameField}" required>
					</div>
					<div class="form-group">
						<label for="userName">{username}</label>
						<input type="text" class="form-control" name="username" value="{usernameField}" required>
					</div>
					<div class="form-group">
						<label for="email">{email}</label>
						<input type="email" class="form-control" name="email" value="{emailField}" required>
					</div>
					<button type="button" class="mb-3 btn primary-color-inverted" data-toggle="modal" data-target="#passwordModal" title="{passwordBtnTitle}">
						{btn_password}
					</button>
					<div class="form-check mb-3" {hidden}>
						<label class="form-check-label" for="myCheckAdmin">
							<input type="checkbox" name="admin" class="form-check-input" id="myCheckAdmin" onclick="showAdminFunction()" {checkedAdmin}>{administrator_check}
						</label>
						<p id="textAdmin" style="display:none; font-style: italic;">{admincheck_explanation}</p>
					</div >
					<div class="row mb-5">
						<div class="col">
							<a class="btn btn-lg primary-color-inverted monitored-btn" href="home" title="{cancelBtnTitle}">{btn_cancel}</a>
						</div>
						<div class="col">
							<p align="right"><button type="submit" id="submitButton" class="btn btn-lg primary-color monitored-btn" title="{saveBtnTitle}">{btn_edit_account}</button></p>
						</div>
					</div>
				</form>
			</div>
			<div class="col-4"></div>
		</div>
	</div>

</main>

<script>
    function showAdminFunction() {
        // Get the checkbox
        const checkBox = document.getElementById("myCheckAdmin");
        // Get the output text
        const text = document.getElementById("textAdmin");

        // If the checkbox is checked, display the output text
        if (checkBox.checked == true){
            text.style.display = "block";
        } else {
            text.style.display = "none";
        }
    }

    function addBorder() {
        document.getElementById("editUser").style.borderBottom = "4px solid white";
        switch("<?php echo $this->session->userdata('site_lang')?>") {
            case "english":
                document.getElementById("dropdownButton").innerHTML = '<img src="<?php echo base_url() ?>assets/icons/077-english.svg" alt="" height="25px" width="auto"> English';
                break;
            case "dutch":
                document.getElementById("dropdownButton").innerHTML = '<img src="<?php echo base_url() ?>assets/icons/076-dutch.svg" alt="" height="25px" width="auto"> Nederlands';
                break;
        }
    }

    window.onload = addBorder();
</script>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<!-- To make sure every field is filled in (https://codereview.stackexchange.com/questions/148072/disable-button-when-required-inputs-are-not-filled-in) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<!-- Script for the avatar selector -->
<script src="<?php echo base_url() ?>assets/styling/js/avatarSelectScript.js"></script>

</body>
</html>
