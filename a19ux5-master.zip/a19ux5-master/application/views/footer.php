

<body class="background-color">

<!-- Nav Footer -->
<header>
	<div class="w3-center nav-footer">
		<nav class="nav nav-pills nav-justified">
			<div class="nav-item pill-1">
				<a class="nav-link {survey-isActive}" href="selectResident" title="{surveyTitle}">{survey}</a>
			</div>
			<div class="nav-item pill-2">
				<a class="nav-link {home-isActive}" href="home" title="{homeTitle}">{home}</a>
			</div>
			<div class="nav-item pill-3">
				<a class="nav-link {manage-isActive}" href="manage" title="{manageTitle}">{manage}</a>
			</div>

		</nav>
	</div>
</header>

</body>
</html>

