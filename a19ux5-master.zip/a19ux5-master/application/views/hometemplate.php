
<body class="background-color">

	<main id="main-home">
		<ul id="flex-container-home">
			<li {hide-home}>
				<button onclick="window.location.href = 'selectResident';" class="btn secondary-color secondary-hover w3-padding-large-button w3-margin btn-home" title="{surveyTitle}">
					<span class="btn-text">{survey}</span>
					<br><br>
					<img src="<?php echo base_url() ?>assets/icons/052-clipboard.svg" alt="" height="200px" width="200px" class="img-home">
				</button>
			</li>
			<li {hide-home}>
				<button onclick="window.location.href = 'manage';" class="btn primary-color primary-hover w3-padding-large-button w3-margin btn-home" title="{manageTitle}">
					<span class="btn-text">{manage}</span>
					<br><br>
					<img src="<?php echo base_url() ?>assets/icons/035-analytics.svg" alt="" height="200px" width="200px" class="img-home">
				</button>
			</li>
			<li {hide-manage}>
				<button onclick="window.location.href = 'charts';" class="btn primary-color primary-hover w3-padding-large-button w3-margin btn-home" title="{resultsTitle}">
					<span class="btn-text">{results}</span>
					<br><br>
					<img src="<?php echo base_url() ?>assets/icons/045-analytics-5.svg" alt="" height="200px" width="200px" class="img-home">
				</button>
			</li>
			<li {hide-manage}>
				<button onclick="window.location.href = 'manageResident';" class="btn primary-color primary-hover w3-padding-large-button w3-margin btn-home" title="{residentsTitle}">
					<span class="btn-text">{residents}</span>
					<br><br>
					<img src="<?php echo base_url() ?>assets/icons/034-server.svg" alt="" height="200px" width="200px" class="img-home">
				</button>
			</li>
			<li {hide-manage}>
				<button onclick="window.location.href = 'lottery';" class="btn primary-color primary-hover w3-padding-large-button w3-margin btn-home" title="{lotteryTitle}">
					<span class="btn-text">{lottery}</span>
					<br><br>
					<img src="<?php echo base_url() ?>assets/icons/057-trophy.svg" alt="" height="200px" width="200px" class="img-home">
				</button>
			</li>
		</ul>
	</main>

</body>
</html>
