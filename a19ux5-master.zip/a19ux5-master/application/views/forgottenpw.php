<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>{page_title}</title>

	<!-- Use Tom as icon of the web tab -->
	<link rel="icon" type="image/png" href="<?php echo base_url() ?>assets/images/tom_32_32px.png" sizes="32x32" />

	<link rel="stylesheet" href="<?php echo base_url()?>assets/styling/css/login.css">

	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</head>
<body>

<form action="" method="post">



<!--	<div class="container">-->
<!---->
<!--		<h1>Request to send a new password</h1>-->
<!---->
<!--		<p style = "color: red">{warningmessage}</p>-->
<!---->
<!--		<p>Please fill in this form to reset your password.</p>-->
<!--		<hr>-->
<!---->
<!--		<label for="email"><b>Email</b></label>-->
<!--		<input type="email" placeholder="Enter Email" name="email" required>-->
<!---->
<!---->
<!--		<button type="submit">Send new password</button>-->
<!---->
<!--		<span class="password">Go back to <a href= 'login'>login</a></span>-->
<!--	</div>-->



	<div class="container">
		<div class="row">
			<div class="col-md-5 mx-auto">
				<div id="first">
					<div class="myform form ">
						<div class="logo mb-3">
							<div class="col-md-12 text-center">
								<h1>Request to send a new password</h1>
								<p style = "color: red">{warningmessage}</p>
								<p>Please fill in this form to reset your password.</p>
							</div>
						</div>
						<form action="" method="post" name="login">
							<div class="form-group">
								<label for="exampleInputEmail1">Email</label>
								<input type="email" class="form-control" aria-describedby="emailHelp" id="email" placeholder="Enter Username" name="email" required>
							</div>
							<div class="form-group">
								<!--							<p class="text-center">By signing up you accept our <a href="#">Terms Of Use</a></p>-->
							</div>
							<div class="col-md-12 text-center ">
								<button type="submit" class=" btn btn-block mybtn  tx-tfm">Send new password</button>
							</div>
							<div class="col-md-12 ">
								<div class="login-or">
									<hr class="hr-or">
									<span class="span-or">or</span>
								</div>
							</div>

							<div class="form-group">
								<p class="text-center">Go back to <a href="login">login</a></p>
							</div>
						</form>

					</div>
				</div>
			</div>
		</div>
	</div>


</form>

</body>
</html>
