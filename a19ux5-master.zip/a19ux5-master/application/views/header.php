<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Use Tom as icon of the web tab -->
	<link rel="shortcut icon" type="image/png" href="<?php echo base_url() ?>assets/images/tom_32_32px.png" sizes="32x32" />

	<!-- CI -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/main.css?<?php echo time(); ?>">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<!-- Our CSS -->
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/styling/css/general_style.css?<?php echo time(); ?>">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/styling/css/caregiver_style.css?<?php echo time(); ?>">

	<title>{page_title}</title>
</head>

<body class="background-color">

<!-- Navbar -->
<header id = "navbar">
	<nav class="navbar navbar-expand-lg navbar-light neutral-color full-width">

		<a class="navbar-brand px-3">
			<img id="account-icon" src="{avatarImage}" alt="" height="50" width="50">
		</a>
		<a class="navbar-brand text-white mr-auto w3-left">
			<div>{nameuser}<br>{nameNH}</div>
		</a>

		<div class="dropdown px-2">
			<button id="dropdownButton" onclick="showDropdown()" class="btn dropdown-toggle dropbtn">
				<img src="<?php echo base_url() ?>assets/icons/076-dutch.svg" alt="" height="25px" width="auto"> Nederlands
			</button>
			<div id="languageDropdown" class="dropdown-content">
				<a class="dropdown-item" href="<?php echo base_url(); ?>LanguageSwitcher/switchLang/dutch">
					<img src="<?php echo base_url() ?>assets/icons/076-dutch.svg" alt="" height="25px" width="auto"> Nederlands
				</a>
				<a class="dropdown-item" href="<?php echo base_url(); ?>LanguageSwitcher/switchLang/english">
					<img src="<?php echo base_url() ?>assets/icons/077-english.svg" alt="" height="25px" width="auto"> English
				</a>
			</div>
		</div>

		<div>
			<a href="{addLink}" id="addUser" title="{addTitle}" class="navbar-brand px-2 nav-icon" style="margin-left: 8px">
				<img src="<?php echo base_url() ?>assets/icons/078-user.svg" alt="" height="40" width="auto">
			</a>
			<a href="editAccount" id="editUser" title="{editTitle}" class="navbar-brand px-2 nav-icon">
				<img src="<?php echo base_url() ?>assets/icons/083-edit.svg" alt="" height="40" width="auto">
			</a>
			<a href="#" id="tutorialModal" onclick="openTutorial()" title="Tutorial" class="navbar-brand px-2 nav-icon">
				<img src="<?php echo base_url() ?>assets/icons/082-question.svg" alt="" height="40" width="auto">
			</a>
			<a href="logout" title="{logoutTitle}" class="navbar-brand px-2 nav-icon">
				<img src="<?php echo base_url() ?>assets/icons/080-exit-1.svg" alt="" height="40" width="auto">
			</a>
		</div>

		<!-- Tutorial Modal -->
		<div class="modal-menu" id="videoModal" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-dialog-video">
				<div class="modal-content">
					<div class="modal-body-video">
						<button type="button" class="close-video close" data-dismiss="modal" aria-hidden="true" onclick="closeTutorial()">
							<span aria-hidden="true">&times;</span>
						</button>
						<!-- 16:9 aspect ratio -->
						<div class="embed-responsive embed-responsive-16by9">
							<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/F4GMR3vK5hM" id="video" allowfullscreen="allowfullscreen" allowscriptaccess="always" allow="autoplay"></iframe>
						</div>
					</div>
				</div>
			</div>
		</div>

		<script type="text/javascript">
            /* When the user clicks on the button, toggle between hiding and showing the dropdown content */
            function showDropdown() {
                document.getElementById("languageDropdown").classList.toggle("show");
            }

            // Close the dropdown menu if the user clicks outside of it
            document.onclick = function(event) {
                if (!event.target.matches('.dropbtn')) {
                    var dropdowns = document.getElementsByClassName("dropdown-content");
                    var i;
                    for (i = 0; i < dropdowns.length; i++) {
                        var openDropdown = dropdowns[i];
                        if (openDropdown.classList.contains('show')) {
                            openDropdown.classList.remove('show');
                        }
                    }
                }
            };

            function openTutorial() {
                document.getElementById("tutorialModal").style.borderBottom = "4px solid white";
                openVideoModal();
			}

			function closeTutorial() {
                document.getElementById("tutorialModal").style.borderBottom = "";
                closeVideoModal();
			}

            window.onload = function () {
                switch("<?php echo $this->session->userdata('site_lang')?>") {
                    case "english":
                        document.getElementById("dropdownButton").innerHTML = '<img src="<?php echo base_url() ?>assets/icons/077-english.svg" alt="" height="25px" width="auto"> English';
                        break;
                    case "dutch":
                        document.getElementById("dropdownButton").innerHTML = '<img src="<?php echo base_url() ?>assets/icons/076-dutch.svg" alt="" height="25px" width="auto"> Nederlands';
                        break;
                }
            };
		</script>

	</nav>
</header>

<script type="text/javascript" src="<?php echo base_url() ?>assets/styling/js/videoModalScript.js"></script>

<script>
    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == videoModal) {
            closeTutorial();
        }
    };
</script>

</body>
</html>
