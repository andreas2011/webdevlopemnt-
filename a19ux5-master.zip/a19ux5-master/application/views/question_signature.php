
<!DOCTYPE HTML>
<html>
<head>
	<title>{pagetitle}</title>

	<!-- Use Tom as icon of the web tab -->
	<link rel="icon" type="image/png" href="<?php echo base_url() ?>assets/images/tom_32_32px.png" sizes="32x32" />


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	<script src="<?php echo base_url() ?>assets/styling/js/jquery-ui.min.js"></script>
	<script src="<?php echo base_url() ?>assets/styling/js/jquery.validate.js"></script>

	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<!-- Our CSS -->
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/styling/css/general_style.css?<?php echo time(); ?>">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/styling/css/survey_style.css?<?php echo time(); ?>">
	<!-- signature -->
	<!-- Jquery Core Js -->
	<script src="<?php echo base_url() ?>assets/js/jquery.min.js"></script>

	<!-- Bootstrap Core Js -->
	<script src="<?php echo base_url() ?>assets/js/bootstrap.min.js"></script>

	<!-- Bootstrap Select Js -->
	<script src="<?php echo base_url() ?>assets/js/bootstrap-select.js"></script>

	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="<?php echo base_url() ?>assets/js/numeric-1.2.6.min.js"></script>
	<script src="<?php echo base_url() ?>assets/js/bezier.js"></script>
	<script src="<?php echo base_url() ?>assets/js/jquery.signaturepad.js"></script>
	<script type='text/javascript' src="https://github.com/niklasvh/html2canvas/releases/download/0.4.1/html2canvas.js"></script>
	<script src="<?php echo base_url() ?>assets/js/json2.min.js"></script>

</head>
<body>
<div class="custom_container">

	<form class="form-horizontal form">
		<div class="container">

			<div class="row-fluid extreme-top-padding">




					<div class="col-sm-12 flexwelcome">

						<div class="welcome-bubble sb text-bubble-size" >
							{tom_text}
						</div>

						<div class="flex-column left-padding" style="display: grid; justify-items: center" >
							<img id="tom_id" alt="Tom de chatbot" class="tom-size">

							<script>
                                document.getElementById('tom_id').setAttribute('src',"{tom_pic}");
							</script>

							<a class="btn text primary-color-inverted btn-listen-width" onclick='readOutLoud()'>
								<div class=" flex-row" style="display: inline-flex">
									<div><p class="text_button top-padding">BELUISTER</p></div>
									<div style="align-self: center; padding-left: 3px;"><img src="<?php echo base_url() ?>assets/icons/055-ear.svg" alt="Question mark" class="icon_small_survey icon_orange"></div>
								</div>
							</a>
						</div>


					</div>

					<div class="form-group">
						<div class="col-sm-12 flex top-padding">

						<div id="signArea" >
							<h2 class="tag-info">Handtekening</h2>
							<div class="sig sigWrapper" style="height:auto;" >
								<div class="typed"></div>
								<canvas class="sign-pad" id="sign-pad" width="730" height="220" onclick="activateNextBtn()" ></canvas>
							</div>
						</div>
						<div class="flex-column">
							<div class="bottom-padding">
								<button id="btnClearSign" type="button" class="action text text-capitalize back btn primary-color-inverted btn-navigate_q"
								><p class="text_button">Wis</p><p class="glyphicon glyphicon-erase" ></p></button>
							</div>


							<a href="{next_link}">
							<div class="bottom-padding">
								<button id="btnSaveSign" type="button" class="action text text-capitalize next btn primary-color-inverted btn-navigate_q" style="background-color: #ff7545"
								><p class="text_button">Ga verder</p><p class="glyphicon glyphicon-arrow-right" ></p></button>
							</div>
							</a>



							<script>
								let btn = document.getElementById('btnSaveSign');
							   //btn.style.visibility = "hidden";
							</script>

						</div>

						</div>

				</div>
			</div>


		</div>
<!--		<div class="col-sm-12 flex top-padding bottom-padding progress-bar-location" >
			<div class="progress" style="width: 90%" >
				<div class="progress-bar progress-bar-success progress-bar-striped text active" role="progressbar" aria-valuemin="0" aria-valuemax="100"
					 style="background-color: #0072BB ; width:100%" ></div>
			</div>
		</div>-->

	</form>
</div>

<script src="<?php echo base_url() ?>assets/styling/js/tom.js"></script>
<script>
    let busy = 0;
    let tom = document.getElementById('tom_id');
    let tomText = "{tom_text}";
    let pic = "{tom_pic}";
    let gif = "{tom_gif}";

    $(document).ready(function() {
        $('#signArea').signaturePad({drawOnly:true, drawBezierCurves:true, lineTop:200});

    });

    $("#btnSaveSign").click(function(e){

        html2canvas([document.getElementById('sign-pad')], {
            onrendered: function (canvas) {
                var canvas_img_data = canvas.toDataURL('image/png');
                var img_data = canvas_img_data.replace(/^data:image\/(png|jpg);base64,/, "");
                //ajax call to save image inside folder
                $.ajax({
                    url: '<?php echo base_url() ?>index.php/Controller/saveSign',
                    data: { img_data:img_data },
                    type: 'post',
                    dataType: 'json',
                    success: function (response) {
                        //window.location.reload();
                    }
                });
            }
        });
    });



    $("#btnClearSign").click(function(e){
        $('#signArea').signaturePad().clearCanvas();
    });


    function activateNextBtn() {
        document.getElementById('btnSaveSign').style.visibility = "visible";
    }

    function deactivateNextBtn() {
        let btn = document.getElementById('btnSaveSign'); // .style.pointerEvents = "none";
        btn.style.visibility = "hidden";
    }
    window.onunload = function () {
        turnOffTomGif();
    }

</script>

</body>
</html>

