
<!DOCTYPE HTML>
<html>
<head>
	<title>{pagetitle}</title>

	<!-- Use Tom as icon of the web tab -->
	<link rel="icon" type="image/png" href="<?php echo base_url() ?>assets/images/tom_32_32px.png" sizes="32x32" />


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	<script src="<?php echo base_url() ?>assets/styling/js/jquery-ui.min.js"></script>
	<script src="<?php echo base_url() ?>assets/styling/js/jquery.validate.js"></script>

	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<!-- Our CSS -->
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/styling/css/general_style.css?<?php echo time(); ?>">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/styling/css/survey_style.css?<?php echo time(); ?>">

</head>
<body>
<div class="custom_container">

	<form class="form-horizontal form">
		<div class="container">

			<div class="row-fluid">
				<br>
				<div class="col-sm-12 flexwelcome">

					<div id="anonymous_text_balloon" class="welcome-bubble sb text-bubble-size">
						{tom_text}
					</div>

					<div class="flex-column" style="display: grid; justify-items: center" >
						<img id="tom_id" alt="Tom de chatbot" class="tom-size">
						<script>
                            document.getElementById('tom_id').setAttribute('src',"{tom_pic}");
						</script>

						<a class="btn text primary-color-inverted btn-listen-width" onclick='readOutLoud()'>
							<div class=" flex-row" style="display: inline-flex">
								<div><p class="text_button top-padding">BELUISTER</p></div>
								<div style="align-self: center; padding-left: 3px;"><img src="<?php echo base_url() ?>assets/icons/055-ear.svg" alt="Question mark" class="icon_small_survey icon_orange"></div>
							</div>
						</a>
					</div>


				</div>

				<div class="form-group">
					<div class="col-sm-12 flex extreme-top-padding">

						<a class="btn btn_choice btn-primary secondary-color btn-width" href="{stop_link}">
							<p class="text_button top-padding">STOP DE VRAGENLIJST</p>
							<img src="<?php echo base_url() ?>assets/icons/073-finish.svg" alt="Finish" class="icon_white icon_survey">
						</a>
						<a class="btn btn_choice btn-primary secondary-color btn-width" href={next_link}>
							<p class="text_button top-padding">GA VERDER</p>
							<img src="<?php echo base_url() ?>assets/icons/068-next-1.svg" alt="Next" class="icon_white icon_survey">
						</a>

					</div>

				</div>

			</div>

		</div>

</div>
<div class="col-sm-12 flex top-padding bottom-padding progress-bar-location" >
	<div class="progress"  style="height: 40px;" style="width: 90%" >
		<div class="progress-bar progress-bar-success progress-bar-striped text active" role="progressbar" aria-valuemin="0" aria-valuemax="100"
			 style="background-color: #0072BB ;font-weight:bold; font-size: large; width:{percent}%" ><p style="padding-top: 10px">{finished} van de 11 categoriëen</p></div>
	</div>

	</form>
</div>

<script src="<?php echo base_url() ?>assets/styling/js/tom.js"></script>
<script>
    let busy = 0;
    let tom = document.getElementById('tom_id');
    let tomText = "{tom_text}";
    let pic = "{tom_pic}";
    let gif = "{tom_gif}";

    window.onunload = function () {
        turnOffTomGif();
    }
</script>
</body>
</html>
