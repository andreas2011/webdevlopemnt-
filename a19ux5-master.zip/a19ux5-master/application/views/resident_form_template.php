<body>
	<!-- Header -->
	<main class="main-selectResident">

		<div class="container-fluid">
			<div class="row">
				<div class="col-4"></div>
				<div class="col-6">
					<h1>{title_h1}</h1>
				</div>
				<div class="col-2"></div>
			</div>

			<div class="row mt-5 mb-5">
				<div class="col-4"></div>
				<div class="col-4">
					<form role="form" action="{saveLink}" method="post">
						<div>
							<input type="text" class="form-control mb-2" name="firstName" placeholder="{first_name}" required>
						</div>
						<div>
							<input type="text" class="form-control mb-2" name="lastName" placeholder="{last_name}" required>
						</div>
						<div>
							<input type="text" class="form-control mb-2" name="roomNumber" placeholder="{room_number}" required>
						</div>
						<div>
							<input type="number" class="form-control" name="birthYear" placeholder="{birth_year}" required>
						</div>

						<div id="btnGender" class="mt-4 btn-group-toggle">
							<label class="btn-lg btn-outline-secondary btn" title="{maleBtnTitle}">
								<input type="radio" name="gender" value="male" title="Man" required>
								{male}
							</label>
							<label class="btn-lg btn-outline-secondary btn" title="{femaleBtnTitle}">
								<input type="radio" name="gender" value="female" title="Vrouw">
								{female}
							</label>
						</div>

						<div class="mt-5 mb-5">
							<a class="btn btn-lg {color_btn_inverted} monitored-btn" href="{backLink}" title="{cancelBtnTitle}">{btn_cancel}</a>
							<button type="submit" id="submitButton" title="{addStartBtnTitle}" class="btn btn-lg {color_btn} monitored-btn">{btn_name}</button>
						</div>
					</form>
				</div>
				<div class="col-4"></div>
			</div>
		</div>
	</main>

	<script>
		// Add active class to the current button (highlight it)
		let div = document.getElementById("btnGender");
		let btns = div.getElementsByClassName("btn");
		for (let i = 0; i < btns.length; i++) {
			btns[i].addEventListener("click", function() {
				let current = div.getElementsByClassName("active");
				if (current.length > 0) {
					current[0].className = current[0].className.replace(" active", "");
				}
				this.className += " active";
			});
		}
	</script>

	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>
