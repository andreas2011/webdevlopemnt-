<!DOCTYPE HTML>
<html lang="en">
<head>
	<title>{pagetitle}</title>

	<!-- Use Tom as icon of the web tab -->
	<link rel="icon" type="image/png" href="<?php echo base_url() ?>assets/images/tom_32_32px.png" sizes="32x32" />

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Lato" />

	<link rel="stylesheet" href="<?php echo base_url() ?>assets/styling/css/general_style.css?<?php echo time(); ?>">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/styling/css/survey_style.css?<?php echo time(); ?>">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	<script src="<?php echo base_url() ?>assets/styling/js/jquery-ui.min.js"></script>
	<script src="<?php echo base_url() ?>assets/styling/js/jquery.validate.js"></script>

	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>

</head>

<body>
<div class="custom_container">
	<form class="form-horizontal form"  method="POST"  action="<?php echo base_url() ?>index.php/Controller/question" >
		<div class="container">

			<div class="row-fluid top-padding">
				<br>
				<div class="step">
					<div class="form-group" >
						<div class="col-sm-12 flex" style="align-items: center">
							<div class="flexColumn" style="justify-items: left">
							<p class="text-bubble-size" style="font-size: large" >Categorie: {category}</p>
							<div class="speech-bubble sb text-bubble-size" >
								<p>{tom_text}</p>
							</div>
							</div>
							<div class="flexColumn">
								<img id="tom_id" src="{tom_pic}" alt="Tom de chatbot" class="tom-size">

								<a class="btn text primary-color-inverted btn-listen-width" onclick='readOutLoud()'>
									<div class=" flex-row" style="display: inline-flex">
										<div><p class="text_button top-padding">BELUISTER</p></div>
										<div style="align-self: center; padding-left: 3px;"><img src="<?php echo base_url() ?>assets/icons/055-ear.svg" alt="Question mark" class="icon_small_survey icon_orange"></div>
									</div>
								</a>
							</div>
						</div>
					</div>
					<div class="form-group top-padding-p">
						<div class="col-sm-12 flex top-padding">

							<label for="radioNooit">
								<a id="btn_nooit" class="btn btn-sq-lg btn_choice text" onclick=activateNextBtn();>
									<p class="text_button top-padding">NOOIT</p>
									<img id="img_nooit" src="<?php echo base_url() ?>assets/icons/033-sad-1.svg" alt="Very sad smiley" class="icon_survey icon_blue img_choice">
									<input type="radio" id="radioNooit" name="radioButton" value="nooit" class="radio-button"style="opacity: 0; width: 0;">
								</a>
							</label>



							<label for="radioZelden">
								<a id="btn_zelden" class="btn btn-sq-lg btn_choice text" onclick="activateNextBtn()">
									<p class="text_button top-padding">ZELDEN</p>
									<img id="img_zelden" src="<?php echo base_url() ?>assets/icons/032-sad.svg" alt="Sad smiley" class="icon_survey icon_blue img_choice">
									<input type="radio" id="radioZelden" name="radioButton" value="zelden"  class="radio-button" style="opacity: 0; width: 0;">
								</a>
							</label>


							<label for="radioSoms">
								<a id="btn_soms" class="btn btn-sq-lg btn_choice text" onclick="activateNextBtn()">
									<p class="text_button top-padding">SOMS</p>
									<img id="img_soms" src="<?php echo base_url() ?>assets/icons/031-sceptic.svg" alt="Average smiley" class="icon_survey icon_blue img_choice">
									<input type="radio" id="radioSoms" name="radioButton" value="soms"  class="radio-button"style="opacity: 0; width: 0;">
								</a>
							</label>

							<label for="radioMeestal">
								<a id="btn_meestal" class="btn btn-sq-lg btn_choice text" onclick="activateNextBtn()">
									<p class="text_button top-padding">MEESTAL</p>
									<img id="img_meestal" src="<?php echo base_url() ?>assets/icons/030-smile.svg" alt="Happy smiley" class="icon_survey icon_blue img_choice">
									<input type="radio" id="radioMeestal" name="radioButton" value="meestal" class="radio-button"style="opacity: 0; width: 0;">
								</a>
							</label>

							<label for="radioAltijd">
								<a id="btn_altijd" class="btn btn-sq-lg btn_choice text" onclick="activateNextBtn()">
									<p class="text_button top-padding">ALTIJD</p>
									<img id="img_altijd" img src="<?php echo base_url() ?>assets/icons/029-happy.svg" alt="Very happy smiley" class="icon_survey icon_blue img_choice">
									<input type="radio" id="radioAltijd" name="radioButton" value="altijd" class="radio-button"style="opacity: 0; width: 0;">
								</a>
							</label>

						</div>


						<div class="col-sm-12 flex top-padding bottom-padding" style="align-items: center">

								<button type="submit" name="previous" value="previous" class="action text text-capitalize next btn primary-color-inverted btn-listen-width">
									<div class=" flex-row" style="display: inline-flex">
										<div style="align-self: center; padding-right: 3px;"><img src="<?php echo base_url() ?>assets/icons/068-next-1.svg" alt="Next" class="icon_small_survey icon_orange"style="transform: scaleX(-1)"></div>
										<div><p class="text_button top-padding">VORIGE</p></div>
									</div>
								</button>
								</a>

								<label for="radioWeetniet">
							<a id="btn_weetniet" class="btn btn-sq-lg btn_choice text" onclick="activateNextBtn()">
								<p class="text_button top-padding">WEET NIET</p>
								<img id="img_weetniet" src="<?php echo base_url() ?>assets/icons/054-info.svg" alt="Question mark" class="icon_survey icon_blue img_choice">
								<input type="radio" id="radioWeetniet" name="radioButton" value="weetniet"  class="radio-button"style="opacity: 0; width: 0;">
							</a>
							</label>

								<button id="btn_next" type="submit" name="next" value="next" class="action text text-capitalize next btn primary-color btn-listen-width">
									<div class=" flex-row" style="display: inline-flex">
										<div><p class="text_button top-padding">VOLGENDE</p></div>
										<div style="align-self: center; padding-left: 3px;"><img src="<?php echo base_url() ?>assets/icons/068-next-1.svg" alt="Next" class="icon_small_survey icon_white"></div>
									</div>
								</button>

							</a>
							<script>
                                let btn = document.getElementById('btn_next');
                                btn.style.visibility = "hidden";
							</script>

						</div>

					</div>

				</div>

			</div>

		</div>

</div>

<div class="col-sm-12 flex top-padding progress-bar-location" >
	<button style="padding: 14px 25px;" id="btnModal" type="button" class="btn text primary-color-inverted " onclick="openModal()">
		<img src="<?php echo base_url() ?>assets/icons/stop.svg" alt="Exit" class="icon_survey icon_orange">
	</button>
	<div class="progress"    style="height: 40px;"  style="width: 90%; height:110%;" >
		<div class="progress-bar progress-bar-success progress-bar-striped text active" role="progressbar" aria-valuemin="0" aria-valuemax="100"
			 style="background-color: #0072BB ; font-weight:bold; font-size: x-large;width:{percent}% " ><p style="padding-top: 10px">{id} van de {total} vragen</p></div>
	</div>



</div>

<script src="<?php echo base_url() ?>assets/styling/js/tom.js"></script>
<script>
    let busy = 0;
    let tom = document.getElementById('tom_id');
    let tomText = "{tom_text}";
    let pic = "{tom_pic}";
    let gif = "{tom_gif}";


    let btns = document.getElementsByClassName("btn_choice");
    let imgs = document.getElementsByClassName("img_choice");

    for (let i = 0; i < btns.length; i++) {

        btns[i].classList.remove("secondary-color");
        btns[i].classList.add("secondary-color-inverted");
        imgs[i].style.filter = "invert(56%) sepia(58%) saturate(563%) hue-rotate(176deg) brightness(96%) contrast(95%)";

        btns[i].addEventListener("click", function() {

            for (let j = 0; j < btns.length; j++) {
                btns[j].classList.remove("secondary-color");
                btns[j].classList.add("secondary-color-inverted");
                imgs[j].style.filter = "invert(56%) sepia(58%) saturate(563%) hue-rotate(176deg) brightness(96%) contrast(95%)";
            }
            this.classList.remove("secondary-color-inverted");
            this.classList.add("secondary-color");
            imgs[i].style.filter = "invert(100%) sepia(100%) saturate(0%) hue-rotate(288deg) brightness(102%) contrast(102%)";
        });
    }
    /***IN CASE YOU GO BACK TO THE PREVIOUS PAGE TO CHECK THE ANSWER***/
	switch("{previous_answer}"){
        case "nooit":
            console.log("btn nooit from beginning");
            document.getElementById("btn_nooit").classList.remove("secondary-color-inverted");
            document.getElementById("btn_nooit").classList.add("secondary-color");
            document.getElementById("img_nooit").style.filter = "invert(100%) sepia(100%) saturate(0%) hue-rotate(288deg) brightness(102%) contrast(102%)";
            activateNextBtn();
			break;
        case "zelden":
            document.getElementById("btn_zelden").classList.remove("secondary-color-inverted");
            document.getElementById("btn_zelden").classList.add("secondary-color");
            document.getElementById("img_zelden").style.filter = "invert(100%) sepia(100%) saturate(0%) hue-rotate(288deg) brightness(102%) contrast(102%)";
            activateNextBtn();
            break;
        case "soms":
            document.getElementById("btn_soms").classList.remove("secondary-color-inverted");
            document.getElementById("btn_soms").classList.add("secondary-color");
            document.getElementById("img_soms").style.filter = "invert(100%) sepia(100%) saturate(0%) hue-rotate(288deg) brightness(102%) contrast(102%)";
            activateNextBtn();
            break;
        case "meestal":
            document.getElementById("btn_meestal").classList.remove("secondary-color-inverted");
            document.getElementById("btn_meestal").classList.add("secondary-color");
            document.getElementById("img_meestal").style.filter = "invert(100%) sepia(100%) saturate(0%) hue-rotate(288deg) brightness(102%) contrast(102%)";
            activateNextBtn();
            break;
        case "altijd":
            document.getElementById("btn_altijd").classList.remove("secondary-color-inverted");
            document.getElementById("btn_altijd").classList.add("secondary-color");
            activateNextBtn();
            document.getElementById("img_altijd").style.filter = "invert(100%) sepia(100%) saturate(0%) hue-rotate(288deg) brightness(102%) contrast(102%)";
            break;
        default:
        	console.log("No previous answer");
            break;
	}


    function activateNextBtn() {
        document.getElementById('btn_next').style.visibility = "visible";
    }
    window.onunload = function () {
        turnOffTomGif();
    }
</script>


</body>
</html>


