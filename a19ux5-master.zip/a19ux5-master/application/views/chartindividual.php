<head>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

	<!--Load the AJAX API-->
	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	<script type="text/javascript">

        // Load the Visualization API and the corechart package.
        google.charts.load('current', {'packages':['corechart','bar']});

        // Set a callback to run when the Google Visualization API is loaded.
        google.charts.setOnLoadCallback(drawChartOverview);

        var options;
        var chart;
        var data;

        function redrawchart(){
            chart.draw(data[0], options);
        }

        // Callback that creates and populates a data table,
        // instantiates the pie chart, passes in the data and
        // draws it.
        function drawChartOverview() {

            var dataWGlobal = google.visualization.arrayToDataTable([
                ["Category", "Edouard Remy","Vlaanderen"],
                {scoresOverview}
                    ['{category}',{average},{global}],
                {/scoresOverview}
            ]);

            var dataNoGlobal = google.visualization.arrayToDataTable([
                ["Category", "Edouard Remy"],
                {scoresOverview}
                    ['{category}',{average}],
                {/scoresOverview}
            ]);

            // Create and populate the data tables.
            data = [];
            data[0] = dataWGlobal;
            data[1] = dataNoGlobal;


            options = {
                backgroundColor: { fill:'transparent' },
                title: '{charttitleOverviewInd} {resident_name}',
                titleTextStyle: {
                    color: "black",    // any HTML string color ('red', '#cc00cc')
                    fontName: "Lato", // i.e. 'Times New Roman'
                    fontSize: 30, // 12, 18 whatever you want (don't specify px)
                    bold: false,
                },
                // hAxis: {slantedText:true, slantedTextAngle:45 },
                legend: {position: 'top', alignment: 'center', textStyle: {fontSize: 16}},
                bar: { groupWidth: "50%" },
                series: {
                    0: {color: '#DE4217'},
                    1: {color: '#0072BB',dataOpacity: 0.55}
                },
                hAxis:{ viewWindow: { min: 0, max: 5 }},
                chartArea:{left:275,top:75},

                // animation:{
                //     startup: 'true',
                //     duration: 600,
                //     easing: 'inAndOut'
                // },


            };

            chart = new google.visualization.BarChart(document.getElementById('chartOverview'));


            var checkBox = document.getElementById('globalCheck');

            var current = 0;

            checkBox.onclick = function() {
                if(checkBox.checked == true){
                    current = 0;
                }
                else{
                    current = 1;
                }
                chart.draw(data[current], options);
            }

            // The select handler. Call the chart's getSelection() method
            function selectHandler() {
                var selectedItem = chart.getSelection()[0];
                if (selectedItem) {
                    var value = data[current].getValue(selectedItem.row, selectedItem.column);
                    var columnlabel = data[current].getColumnLabel(selectedItem.column); //score or global
                    var category = data[current].getValue(selectedItem.row, 0);
                    //alert('The user selected value: ' + value + ' row= ' + category + " column: " + columnlabel);
                    //if(columnlabel.localeCompare("Score")===0)
                    {
                        //do something
                        var theForm, newInput1;
                        // Start by creating a <form>
                        theForm = document.createElement('form');
                        theForm.action = './chartsindcategory';
                        theForm.method = 'post';
                        // Next create the <input>s in the form and give them names and values
                        newInput1 = document.createElement('input');
                        newInput1.type = 'hidden';
                        newInput1.name = 'category';
                        newInput1.value = category;
                        // Now put everything together...
                        theForm.appendChild(newInput1);
                        // ...and it to the DOM...
                        document.getElementById('hidden_form_container').appendChild(theForm);
                        // ...and submit it
                        theForm.submit();
                    }


                }
            }

            // Listen for the 'select' event, and call my function selectHandler() when
            // the user selects something on the chart.
            google.visualization.events.addListener(chart, 'select', selectHandler);

            // Convert the Classic options to Material options.
            chart.draw(data[current], options);
            // window.addEventListener('resize', drawChartOverview, false);
        }



	</script>
	<script type="text/javascript">




        // Load the Visualization API and the corechart package.
        google.charts.load('current', {'packages':['corechart']});

        // Set a callback to run when the Google Visualization API is loaded.
        google.charts.setOnLoadCallback(drawChartProgress);

        var options2;
        var chartProgress;
        var timegrouped;
        var current;
        var data2;

        function redrawchartProgress(){
            options2['title'] = '{De progressie} ' + timegrouped[current] + ' {charttitlecategory}';

            chartProgress.draw(data2[current], options2);
        }

        // Callback that creates and populates a data table,
        // instantiates the pie chart, passes in the data and
        // draws it.
        function drawChartProgress() {

            var dataMonth = google.visualization.arrayToDataTable([
                ["Time", "Score"],
                {scoresProgress_month}
            ]);

            var data3Months = google.visualization.arrayToDataTable([
                ["Time", "Score"],
                {scoresProgress_3months}
            ]);

            var dataHalfYear = google.visualization.arrayToDataTable([
                ["Time", "Score"],
                {scoresProgress_halfyear}
            ]);

            var dataYear = google.visualization.arrayToDataTable([
                ["Time", "Score"],
                {scoresProgress_year}
            ]);

            // Create and populate the data tables.
            data2 = [];
            data2[0] = dataMonth;
            data2[1] = data3Months;
            data2[2] = dataHalfYear;
            data2[3] = dataYear;

            timegrouped = [];
            timegrouped[0] = "{maandelijks}";
            timegrouped[1] = "3 {maandelijks}";
            timegrouped[2] = "half {jaarlijks}";
            timegrouped[3] = "{jaarlijks}";

            current = 0;

            var button1 = document.getElementById('btn1Progress');
            var button2 = document.getElementById('btn2Progress');
            var button3 = document.getElementById('btn3Progress');
            var button4 = document.getElementById('btn4Progress');

            button1.onclick = function(){
                current=0;
                redrawchartProgress();
            };

            button2.onclick = function(){
                current=1;
                redrawchartProgress();
            };

            button3.onclick = function(){
                current=2;
                redrawchartProgress();
            };

            button4.onclick = function(){
                current=3;
                redrawchartProgress();
            };





            options2 = {
                backgroundColor: { fill:'transparent' },
                title: '{De progressie} ' + timegrouped[current] + ' {charttitlecategory}',
                titleTextStyle: {
                    color: "black",    // any HTML string color ('red', '#cc00cc')
                    fontName: "Lato", // i.e. 'Times New Roman'
                    fontSize: 30, // 12, 18 whatever you want (don't specify px)
                    bold: false,
                },
                // hAxis: {slantedText:true, slantedTextAngle:45 },
                legend: {position: 'none'},
                bar: { groupWidth: "50%" },
                series: {
                    0: {color: '#DE4217'},
                    1: {color: '#0072BB',dataOpacity: 0.55}
                },
                hAxis: {direction: -1},
                vAxis:{ viewWindow: { min: 0, max: 5 }},

                animation:{
                    startup: 'true',
                    duration: 500,
                    easing: 'inAndOut'
                },
                chartArea:{left:50,top:50},


            };

            chartProgress = new google.visualization.LineChart(document.getElementById('chartProgress'));


            // Convert the Classic options to Material options.
            chartProgress.draw(data2[current], options2);
            // window.addEventListener('resize', drawChartProgress, false);
        }
	</script>

	<script>
        $(window).resize(function () {
            drawChartOverview();
            drawChartProgress();
        });
	</script>

</head>

<body>

<style>


	#chartOverview{
		width: 1200px;
		height: 600px;
	}

	#chartProgress{
		width: 1000px;
		height: 500px;
	}

</style>



<!-- Main -->
<main class="main-selectResident">

	<script>
        function openCity(evt, cityName) {
            // Declare all variables
            var i, tabcontent, tablinks;

            // Get all elements with class="tabcontent" and hide them
            tabcontent = document.getElementsByClassName("tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }

            // Get all elements with class="tablinks" and remove the class "active"
            tablinks = document.getElementsByClassName("tablinks");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
            }

            // Show the current tab, and add an "active" class to the button that opened the tab
            document.getElementById(cityName).style.display = "block";
            evt.currentTarget.className += " active";

            if(cityName=='Paris')
                redrawchartProgress();
        }


	</script>

	<div class="flex-column">
		<button onclick="window.location.href = 'charts';" style="box-shadow: none;" class="btn btn-sm primary-color-inverted monitored-btn" title="{overviewBtnTitle}">{backToOverview}</button>

		<div class="bottom-padding">&nbsp;</div>
<!--		<h1>{chartind_title_h1}</h1>-->


	</div>

	<!-- Tab links -->
	<div class="tab">
		<button class="tablinks" onclick="openCity(event, 'London')" id="defaultOpen" title="{overviewTitle}">{charts_overzicht}</button>
		<button class="tablinks" onclick="openCity(event, 'Paris')" title="{progressionTitle}">{charts_progressie}</button>
	</div>

	<!-- Tab content -->
	<div id="London" class="tabcontent">

		<h2>{charts_clickoncat}</h2>
		<div>{charts_compareWglobal} <input type="checkbox" id="globalCheck" checked></div>

		<div id="hidden_form_container" style="display:none;"></div>

		<div id="chartOverview"></div>
	</div>

	<div id="Paris" class="tabcontent">
		{charts_progresspast}
		<div class="btn-toolbar" role="toolbar" aria-label="Toolbar with button groups">
			<div class="btn-group-sm mr-2" role="group" aria-label="First group">
				<button id="btn1Progress" type="button" class="btn btn-secondary" title="{monthTitle}">{maand}</button>
				<button id="btn2Progress" type="button" class="btn btn-secondary" title="{monthsTitle}">3 {maanden}</button>
				<button id="btn3Progress" type="button" class="btn btn-secondary" title="{halfYearTitle}">half {jaar}</button>
				<button id="btn4Progress" type="button" class="btn btn-secondary" title="{yearTitle}">{jaar}</button>
			</div>
		</div>


		<div id="chartProgress"></div>
	</div>


	<script>
        // Get the element with id="defaultOpen" and click on it
        document.getElementById("defaultOpen").click();
	</script>




</main>



<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<!-- To make sure every field is filled in (https://codereview.stackexchange.com/questions/148072/disable-button-when-required-inputs-are-not-filled-in) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>




</body>
</html>


