
<!DOCTYPE HTML>
<html>
<head>
	<title>{pagetitle}</title>

	<!-- Use Tom as icon of the web tab -->
	<link rel="icon" type="image/png" href="<?php echo base_url() ?>assets/images/tom_32_32px.png" sizes="32x32" />


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	<script src="<?php echo base_url() ?>assets/styling/js/jquery-ui.min.js"></script>
	<script src="<?php echo base_url() ?>assets/styling/js/jquery.validate.js"></script>

	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<!-- Our CSS -->
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/styling/css/general_style.css?<?php echo time(); ?>">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/styling/css/survey_style.css?<?php echo time(); ?>">

</head>
<body>
	<div class="custom_container">
		<br>
		<form class="form-horizontal" method="POST" action="../../index.php/Controller/setAnonymous">
			<div class="container">

				<div class="row-fluid">
					<br>
					<div class="col-sm-12 flexwelcome" style="align-items: center">

							<div id="anonymous_text_balloon" class="welcome-bubble sb text-bubble-size">
								{tom_text}
							</div>

						<div class="flex-column" style="display: grid; justify-items: center">
							<img id="tom_id" src="{tom_pic}" alt="Tom de chatbot" class="tom-size">

							<a class="btn text primary-color-inverted btn-listen-width" onclick='readOutLoud()'>
								<div class=" flex-row" style="display: inline-flex">
									<div><p class="text_button top-padding">BELUISTER</p></div>
									<div style="align-self: center; padding-left: 3px;"><img src="<?php echo base_url() ?>assets/icons/055-ear.svg" alt="Question mark" class="icon_small_survey icon_orange"></div>
								</div>
							</a>
						</div>


					</div>

					<div class="form-group">
						<div class="col-sm-12 flex extreme-top-padding">

							<label for="radioAno" style="width: 40%; text-align: center">
								<a class="btn btn_choice secondary-color-inverted btn-width" onclick="anonymousClick()">
									<p class="text_button top-padding">ANONIEM</p>
									<div style="align-self: center; padding-left: 3px;"><img src="<?php echo base_url() ?>assets/icons/user-cg-anonymous.svg" alt="Question mark" class="icon_survey icon_light_blue img_choice"></div>
									<input type="radio" id="radioAno" name="radioButtonAno" value="1" class="radio-button"style="opacity: 0; width: 0;">
								</a>
							</label>
							<label for="radioNonAno" style="width: 40%; text-align: center">
								<a class="btn btn_choice secondary-color-inverted btn-width" onclick="nonAnonymousClick()">
									<p class="text_button top-padding">NIET ANONIEM</p>
									<div style="align-self: center; padding-left: 3px;"><img src="<?php echo base_url() ?>assets/icons/user-cg.svg" alt="Question mark" class="icon_survey icon_light_blue img_choice"></div>
									<input type="radio" id="radioNonAno" name="radioButtonAno" value="0" class="radio-button"style="opacity: 0; width: 0;">
								</a>
							</label>

								<script>
									function anonymousClick(){
									    activateStartBtn();
										pic = '{tom_anon_pic}';
                                        gif = '{tom_anon_gif}';
										turnOffTomGif();
									}

									function nonAnonymousClick() {
										activateStartBtn();
                                        pic = '{tom_pic}';
                                        gif = '{tom_gif}';
										turnOffTomGif();
                                    }
								</script>

						</div>

					</div>
					<div class="col-sm-12 flex">

						<button id="btn_start" style="height: 88px" onclick="goFirstQuestion()"  class="btn btn-primary secondary-color">
							<p class="text_button" style="margin-bottom: 0">START DE VRAGENLIJST</p>
						</button>


						<script>
							let btn = document.getElementById('btn_start');
							btn.style.visibility = "hidden";
						</script>


					</div>

				</div>

			</div>

	</div>
		<div class="col-sm-12 flex top-padding bottom-padding progress-bar-location" >
			<button style="padding: 14px 25px;" id="btnModal" type="button" class="btn text primary-color-inverted " onclick="openModal()">
				<img src="<?php echo base_url() ?>assets/icons/stop.svg" alt="Exit" class="icon_survey icon_orange">
			</button>
			<div class="progress"  style="height: 40px;" style="width: 90%" >
				<div class="progress-bar progress-bar-success progress-bar-striped text active" role="progressbar" aria-valuemin="0" aria-valuemax="100"
					 style="background-color: #0072BB ; font-weight:bold; font-size: x-large; width:0.9%" ></div>
			</div>

		</div>
	</form>


	<script src="<?php echo base_url() ?>assets/styling/js/tom.js"></script>
	<script>
        let busy = 0;
        let tom = document.getElementById('tom_id');
        let tomText = "{tom_text}";
        let pic = "{tom_pic}";
        let gif = "{tom_gif}";


		let btns = document.getElementsByClassName("btn_choice");
        let imgs = document.getElementsByClassName("img_choice");

		for (let i = 0; i < btns.length; i++) {

		    btns[i].classList.add('secondary-color-inverted');
			// btns[i].style.backgroundColor = "white";
			// btns[i].style.color = "#0072BB";

			btns[i].addEventListener("click", function() {

				for (let j = 0; j < btns.length; j++) {
				    btns[j].classList.remove('secondary-color');
				    btns[j].classList.add('secondary-color-inverted');
                    imgs[j].style.filter = "invert(56%) sepia(58%) saturate(563%) hue-rotate(176deg) brightness(96%) contrast(95%)";
					// btns[j].style.backgroundColor = "white";
					// btns[j].style.color = "#0072BB";
				}
				this.classList.remove('secondary-color-inverted');
				this.classList.add('secondary-color');
                imgs[i].style.filter = "invert(100%) sepia(100%) saturate(0%) hue-rotate(288deg) brightness(102%) contrast(102%)";
				// this.style.backgroundColor = "#0072BB";
				 // this.style.color = "white";
			});
		}
        function activateStartBtn() {
            document.getElementById('btn_start').style.visibility = "visible";
        }
        window.onunload = function () {
            turnOffTomGif();
        }
	</script>

</body>
</html>
