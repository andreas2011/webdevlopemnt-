<!DOCTYPE html>
<html lang="en">

<!-- The Modal -->
<div id="modalMenu" class="modal-menu">

	<!-- Modal content -->
	<div class="modal-content-menu">
		<p class="text-modal" style="text-align: center"> Zeker dat je wilt stoppen? </p>
		<div class="d-flex flex-row bd-highlight mb-3" style="display: flex; justify-content: space-evenly; height: 90%; align-items: center" >
			<button  type="button" onclick ="window.location = '{signature_link}'" class="btn btn-sq-extra-lg secondary-dark-color btn-border" >
				<div class="w3-margin-top w3-margin-button w3-margin-bottom-button">
					<p class="text-bubble-size" style="text-align-last: center">JA </p>
				</div>
			</button>
			<div style="padding: 2%"></div>
			<button onclick="closeModal()" class="btn btn-sq-extra-lg primary-dark-color btn-border ">
				<div class="w3-margin-button w3-margin-bottom-button">
					<p class="text-bubble-size" style="text-align-last: center">NEE</p>
				</div>
			</button>
		</div>
	</div>

</div>

<script>
	// Get the modal
	let modal = document.getElementById("modalMenu");
	function openModal() {
		modal.style.display = "block";
	}

	function closeModal() {
		modal.style.display = "none";
	}
	// When the user clicks anywhere outside of the modal, close it
	window.onclick = function(event) {
		if (event.target == modal) {
			closeModal();
		}
	}
</script>
