<!doctype html>
<html lang="en">

<body>
<!-- Header -->
<header class="main-selectResident">

	<div class="container-fluid">
		<div class="row">
			<div class="col-3"></div>
			<div class="col-6">
				<h1 class="mt-3">{title_h1}</h1>
			</div>
			<div class="col"></div>
		</div>

		<div class="row">
			<div class="col-3"></div>
			<div class="col-4">
				<form class="mt-5" role="form" action="{saveLink}" method="post">
					<div class="form-group">
						<label for="firstName">{first_name}</label>
						<input type="text" class="form-control mb-2" name="firstName" placeholder={first_name} value="{firstName}"required>
					</div>
					<div class="form-group">
						<label for="lastName">{last_name}</label>
						<input type="text" class="form-control mb-2" name="lastName" placeholder="{last_name}" value="{lastName}" required>
					</div>
					<div class="form-group">
						<label for="roomNumber">{room_number}</label>
						<input type="text" class="form-control mb-2" name="roomNumber" placeholder="{room_number}" value="{roomNumber}" required>
					</div>
					<div class="form-group">
						<label for="birthYear">{birth_year}</label>
						<input type="number" class="form-control" name="birthYear" placeholder="{birth_year}" value={birthYear} required>
					</div>
					<div class="form-group">
						<label>{gender}</label>
						<div id="btnGender" class="btn-group-lg btn-group-toggle" data-toggle="buttons">
							<label id="radioBtnMale" class="btn-lg btn-outline-secondary btn {genderMale}" title="{maleBtnTitle}">
								<input type="radio" name="gender" value="male" title="Man" class="toggle" {checkedMale}>
								{male}
								</input>
							</label>
							<label id="radioBtnFemale" class="btn-lg btn-outline-secondary btn {genderFemale}" title="{femaleBtnTitle}">
								<input type="radio" name="gender" value="female" title="Vrouw" class="toggle" {checkedFemale}>
								{female}
								</input>
							</label>
						</div>
					</div>
					<div class="form-group">
						<label>{activity}</label>
						<div id="btnActive" class="btn-group-lg btn-group-toggle" data-toggle="buttons" title="{activeBtnTitle}">
							<label class="btn-lg btn-outline-secondary btn {activeState}">
								<input type="radio" name="(non)active" value="1" title="Actief" class="toggle" {checkedActive}>
								{active}
								</input>
							</label>
							<label class=" btn-lg btn-outline-secondary btn {nonactiveState}" title="{nonactiveBtnTitle}">
								<input align="right" type="radio" name="(non)active" value="0" title="Nonactief" class="toggle" {checkedNonactive}>
								{nonactive}
								</input>
							</label>
						</div>
					</div>
					<a type="button" class="mt-3 btn primary-color-inverted" href="firstSignManage" title="{signatureBtnTitle}" {hidden}>
						{signature_btn}
					</a>

					<div class="row mb-5 mt-5">
						<div class="col">
							<a class="btn btn-lg primary-color-inverted monitored-btn" href="manageResident" title="{cancelBtnTitle}">{btn_cancel}</a>
						</div>
						<div class="col">
							<p align="right"><button type="submit" id="submitButton" class="btn btn-lg primary-color monitored-btn" title="{saveBtnTitle}">{btn_name}</button></p>
						</div>
					</div>
				</form>
			</div>
			<div class="col"></div>
		</div>
	</div>
</header>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>
