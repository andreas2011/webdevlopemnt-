<body>
	<div class="container">
		<div class="row">
			<div class="col-1"></div>
			<div class="col-10">
				<div class="row">
					<div class="col w-100">
						<p><br></p>
						<h1>{title_h1}</h1>
					</div>
				</div>
				<div class="row"><br></div>
				<div class="row">
					<div class="col-sm-7">
						<h3>{residentLabel}: <input type="text" class="searchbar" name="name" placeholder=" {residentFieldLabel}" onkeyup="showTable(this.value)"></h3>
					</div>
					<div class="col">
						<p align="right"><button onclick="window.location='{add_link}'" title="{add_title}" class="btn btn-lg {color_btn} ml-lg-3 align-right">{add_btn_name}</button></p>
					</div>
				</div>
				<div class="row"><br></div>
				<div class="row">
					<div id="checkDiv" class="w-100 form-control-lg">
						<input id="checker" type="checkbox" value="" onclick="showTable(this.value)">{show_allInactive}
					</div>
				</div>
				<div class="row">
					<div id="checkDiv2" class="w-100 form-control-lg">
						<label class="form-check-label">
							<input id="checkersignature" type="checkbox" value="" onclick="showTable(this.value)">{show_allWOSig}
						</label>
					</div>
				</div>
				<div class="row">
					<div class="col w-100">
						<table id="residentTable" class="table table-hover table-bordered">
							<thead class="{table_head_color}">
							<tr>
								<th class="th- col-auto" onclick="sortTable(0)"><h3><b>{nameLabel}</b><img id="imgName" src="<?php echo base_url() ?>assets/icons/double-arrow.svg" height="20" width="auto" align="right"></h3></th>
								<th class="th-sm col-auto" onclick="sortTable(1)"><h3><b>{roomNumberLabel}</b><img id="imgRoom" src="<?php echo base_url() ?>assets/icons/double-arrow.svg" height="20" width="auto" align="right"></h3></th>
								<th class="th-sm col-auto" onclick="sortTable(2)"><h3><b>{latestLabel}</b><img id="imgTime" src="<?php echo base_url() ?>assets/icons/double-arrow.svg" height="20" width="auto" align="right"></h3></th>
								<th class="th-sm col-auto"></th>
							</tr>
							</thead>
							<tbody id="tablecontent">
							</tbody>
						</table>
					</div>
				</div>
				<div class="row"><br><br><br></div>
			</div>
			<div class="col-1"></div>
		</div>
	</div>

	<script>
        let o = "{ordertype}";
        let color = "{color_btn}";
        let link = "{start_link}";
	</script>
	<script src="<?php echo base_url() ?>assets/styling/js/table.js"></script>
	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>
