<body>
	<!-- Header -->
	<main class="main-selectResident">

		<div class="container-fluid">
			<div class="row">
				<div class="col-3"></div>
				<div class="col-6">
					<h1 class="bottom-padding margin-bottom">{title_h1}</h1>
				</div>
				<div class="col-3"></div>
			</div>
<!--			<div class="margin-bottom w3-padding-64">&nbsp;</div>-->

			<div class="row">
				<div class="col-3"></div>
				<div class="col-3">
					<form class="w3-padding-64 flex-container-residentForm" role="form" method="post" action="lotterywinner">
						<select name="timerange" class="form-control" id="timerange" required>
							<!--					<option selected>Selecteer het tijdsinterval waarin een bewoner een vragenlijst moet ingevuld hebben.</option>-->
							<option value="- 1 week">{last_week}</option>
							<option value="- 1 month">{last_month}</option>
							<option value="- 6 month">{last_half_year}</option>
							<option value="- 1 year">{last_year}</option>
						</select>

						<div class="w3-padding-64 btn-block">
							<button type="submit" id="submitButton" class="btn btn-lg primary-color monitored-btn" title="{lotteryBtnTitle}">{btn_name}</button>
						</div>
					</form>
				</div>
				<div class="col-6"></div>
			</div>
		</div>
	</main>


	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


</body>
</html>
