<?php


class Controller extends CI_Controller
{
	/**
	 * Controller constructor.
	 */
	public function __construct()
	{
		parent::__construct();
		$this->load->library('parser');
		$this->load->helper('url');
		$this->load->model('Login_model');
		$this->load->model('Resident_form_model');
		$this->load->model('Database_model');
		$this->lang->load('caregiver','english');

		if (!isset($_SESSION)) {
			session_start();
		}
	}



//	---------------PRIVATE FUNCTIONS----------------


	private function parse_header($title){
		$data{'page_title'} = $title;
		$userid = $this->checkIfLoggedIn();
		$caregiverinfo = $this->Database_model->get_name($userid);
		$data['nameuser'] = $caregiverinfo['name'];
		$data['nameNH'] = $caregiverinfo['nh'];
		$adminFunction = $caregiverinfo['adminFunction'];
		if($adminFunction == 0) {
			$data['addLink'] = "addResident";
			$data['addTitle'] = $this->lang->line('add_resident_header');
		} else {
			$data['addLink'] = "addingChoice";
			$data['addTitle'] = $this->lang->line('add_resident_cg_header');
		}
		$data['editTitle'] = $this->lang->line('edit_header');
		$data['logoutTitle'] = $this->lang->line('logout_header');

		$data['avatarImage'] = base_url().$_SESSION['avatar'];
		$this->parser->parse('header', $data);
	}

	private function parse_footer($data){
		$data['survey'] = $this->lang->line('survey');
		$data['home'] = $this->lang->line('home');
		$data['manage'] = $this->lang->line('manage');
		$data['surveyTitle'] = $this->lang->line('survey_title');
		$data['homeTitle'] = $this->lang->line('home_title');
		$data['manageTitle'] = $this->lang->line('manage_title');
		$this->parser->parse('footer', $data);
	}

	private function getActivetab($tab){
		$data['survey-isActive'] = "";
		$data['home-isActive'] = "";
		$data['manage-isActive'] = "";
		if($tab=="survey"){
			$data['survey-isActive']="active";
		}
		else if($tab=="home"){
			$data['home-isActive']="active";
		}
		else if($tab=="manage"){
			$data['manage-isActive']="active";
		}
		return $data;
	}

	private function checkIfLoggedIn(){

		if (!(isset($_SESSION['user_id']))) {
			$url = base_url()."index.php/Controller/login";
			header("Location: $url");
			return -1;
		}
		else{
			return $_SESSION['user_id'];
		}
	}

	private function getCaregiverName(){
		if(isset($_SESSION['user_id'])){
			$userid = $_SESSION['user_id'];
		}
		else{
			$userid = "error!";
		}
		$caregiverinfo = $this->Database_model->get_name($userid);
		return $caregiverinfo['firstname'];
	}

	private function getNameLabels(){
		$data['first_name'] = $this->lang->line('first_name');
		$data['last_name'] = $this->lang->line('last_name');
		$data['username'] = $this->lang->line('username');
		$data['gender'] = $this->lang->line('gender');
		$data['activity'] = $this->lang->line('activity');
		$data['email'] = $this->lang->line('email');
		$data['password'] = $this->lang->line('password');
		$data['administrator_check'] = $this->lang->line('administrator_check');
		$data['admincheck_explanation'] = $this->lang->line('admincheck_explanation');
		$data['btn_new_user'] = $this->lang->line('btn_new_user');
		$data['btn_cancel'] = $this->lang->line('btn_cancel');
		$data['navBarSurvey'] = 'font-weight-bold w3-red';
		$data['navBarHome'] = $data['navBarData'] = 'font-weight-light btn-secondary';
		$data['avatar_text'] = $this->lang->line('avatar_text');

		$data['room_number'] = $this->lang->line('room_number');
		$data['birth_year'] = $this->lang->line('birth_year');
		$data['male'] = $this->lang->line('male');
		$data['female'] = $this->lang->line('female');
		$data['active'] = $this->lang->line('active');
		$data['nonactive'] = $this->lang->line('nonactive');
		return $data;
	}

	private function getTableLabels(){
		$data['resident_b'] = $this->lang->line('resident_b');
		$data['search_resident_on_name'] = $this->lang->line('search_resident_on_name');
		$data['search'] = $this->lang->line('search');
		$data['name'] = $this->lang->line('name');
		$data['room_number'] = $this->lang->line('room_number');
		$data['latest'] = $this->lang->line('latest');
		return $data;
	}

	private function getColorBtn($color){
		if($color=="primaryinv"){
			$data['color_btn'] = "primary-color-inverted";
			$data['table_head_color'] = "primary-color";
		}
		else if($color=="primary"){
			$data['color_btn'] = "primary-color";
			$data['color_cancel_btn'] = "primary-color-inverted";
			$data['color_btn_inverted'] = "primary-color-inverted";
		}
		else if($color=="secondary"){
			$data['color_btn'] = "secondary-color";
			$data['color_cancel_btn'] = "secondary-color-inverted";
			$data['color_btn_inverted'] = "secondary-color-inverted";
		}
		else if($color=="secondaryinv"){
			$data['color_btn'] = "secondary-color-inverted";
			$data['table_head_color'] = "secondary-color";
		}
		return $data;
	}

	private function getGraphsLabels(){
		$data['charts_clickoncat'] = $this->lang->line('charts_clickoncat');
		$data['charts_compareWglobal']=$this->lang->line('charts_compareWglobal');
		$data['charts_overzicht']=$this->lang->line('charts_overzicht');
		$data['charts_progressie']=$this->lang->line('charts_progressie');
		$data['charts_stacked']=$this->lang->line('charts_stacked');
		$data['charts_individual']=$this->lang->line('charts_individual');
		$data['charts_progresspast']=$this->lang->line('charts_progresspast');
		$data['De progressie']=$this->lang->line('De progressie');
		$data['jaar']=$this->lang->line('jaar');
		$data['maand']=$this->lang->line('maand');
		$data['maanden']=$this->lang->line('maanden');
		$data['maandelijks']=$this->lang->line('maandelijks');
		$data['jaarlijks'] = $this->lang->line('jaarlijks');
		$data['charttitleOverview']= $this->lang->line('charttitleOverview');
		$data['charts_individualtab_h1'] = $this->lang->line('charts_individualtab_h1');
		$data['charts_stacktitle']=$this->lang->line('charts_stacktitle');
		$data['backToOverview']=$this->lang->line('backToOverview');
		$data['charttitleOverview_cattab'] = $this->lang->line('charttitleOverviewCat');
		$data['charttitleOverviewInd']= $this->lang->line('charttitleOverviewInd');
		return $data;
	}



	private function getTom(){
		$data['tom_pic']=base_url()."assets/images/tom_1.png";
		$data['tom_gif']=base_url()."assets/images/tom_gif.gif";
		return $data;
	}

	private function getTomAnonymous(){
		$anon=$this->Database_model->getanon();
		if($anon){
			$data['tom_pic']=base_url()."assets/images/tom_ano1.png";
			$data['tom_gif']=base_url()."assets/images/tom_ano_gif.gif";
		}
		else{
			$data['tom_pic']=base_url()."assets/images/tom_1.png";
			$data['tom_gif']=base_url()."assets/images/tom_gif.gif";
		}
		return $data;
	}

	private function getChartsButtonLabels() {
		$data['overviewTitle'] = $this->lang->line('overview_title');
		$data['progressionTitle'] = $this->lang->line('progress_title');
		$data['individualTitle'] = $this->lang->line('individual_title');
		$data['distributionTitle'] = $this->lang->line('distribution_title');
		$data['monthTitle'] = $this->lang->line('month_title');
		$data['monthsTitle'] = $this->lang->line('months_title');
		$data['halfYearTitle'] = $this->lang->line('half_year_title');
		$data['yearTitle'] = $this->lang->line('year_title');
		$data['overviewBtn'] = $this->lang->line('backToOverview');
		$data['overviewBtnTitle'] = $this->lang->line('overview_btn_title');

		return $data;
	}


//	---------------PUBLIC FUNCTIONS----------------
	public function index(){
		$title = $this->lang->line('home_title_tab');
		$data = $this->getActivetab("home");
		$data['hide-home'] = "";
		$data['hide-manage'] = "hidden";

		$data['survey'] = $this->lang->line('survey');
		$data['home'] = $this->lang->line('home');
		$data['manage'] = $this->lang->line('manage');

		$data['surveyTitle'] = $this->lang->line('survey_title');
		$data['manageTitle'] = $this->lang->line('manage_title');

		$this->parse_header($title);
		$this->parser->parse('hometemplate',$data);
		$this->parse_footer($data);
	}


	/* -.-.-.-.-.- LOGIN/SIGNUP/ACCOUNT FUNCTIONS -.-.-.-..- */
	public function login(){

		if ( isset( $_SESSION['user_id'] ) ) {
			echo "Already logged in!";
			$data['alertfct']="success";
			$data['warningmessage'] = "You are logged in";
			$url = base_url()."index.php/Controller/home";
			header("Location: $url");
		}
		else{
			$data['warningmessage'] = "";
		}

		$username = ($this->input->post('username'));
		$password = ($this->input->post('password'));

		if(!empty($username) && !empty($password)){
			$username = htmlspecialchars($username, ENT_QUOTES);
			$password = htmlspecialchars($password, ENT_QUOTES);
			$logindetails = array(
				'username' => $username,
				'password' => $password,
			);

			$errors = $this->Login_model->loginuser($logindetails);

			$user_no_exist = $errors['user_no_exist'];
			$pass_incorrect = $errors['pass_incorrect'];
			if($user_no_exist==1){
				$data['alertfct']="danger";
				$data['warningmessage'] = "wrong username";
			}
			else if($pass_incorrect==1){
				$data['alertfct']="danger";
				$data['warningmessage'] = "wrong password";
			}
		}

		$data['page_title'] = "Login | UXWD NH Survey";

		$this->parser->parse('login',$data);
	}


	public function forgottenpw()
	{
		if (isset($_SESSION['user_id'])) {
			echo "Already logged in!";
			$url = base_url()."index.php/Controller/home";
			header("Location: $url");
		}

		$email = ($this->input->post('email'));
		$email_exists = 0;
		if (!empty($email)) {
			$email = htmlspecialchars($email, ENT_QUOTES);
			$email_exists = $this->Login_model->forgotpassword($email);
			if ($email_exists == 0) {
				$data['alertfct']="danger";
				$data['warningmessage'] = "Email doesn't exist. Please try again.";
			} else {
				$data['alertfct']="success";
				$data['warningmessage'] = "Password changed. Check your email";
			}
		}
		else{
			$data['warningmessage'] = "";
		}

		$data['page_title'] = "Login | UXWD NH Survey";

		if($email_exists==0)
			$this->parser->parse('forgottenpw',$data);
		else
			$this->parser->parse('login',$data);
	}

	public function addingChoice() {
		$title = $this->lang->line('addResident_title_tab');
		$data = $this->getActivetab("manage");

		$data['btn_resident'] = $this->lang->line('add_resident_header');
		$data['btn_user'] = $this->lang->line('add_caregiver_header');


		$this->parse_header($title);
		$this->parser->parse('adding_choice', $data);
		$this->parse_footer($data);
	}


	public function signup()
	{
		$caregiverinfo = $this->Database_model->get_name($_SESSION['user_id']);
		$adminFunction = $caregiverinfo['adminFunction'];
		if($adminFunction == 0) {
			$url = base_url()."index.php/Controller/home";
			header("Location: $url");
		}

		else {
			$title = $this->lang->line('signup_title_tab');
			$data = $this->getActivetab("manage");
			$data['linkCheckById'] = "signup";
			$data['title_h1'] = $this->lang->line('add_new_user');
			$data['formactionLink'] = "signupuser";
			$data['accountAvatar'] = base_url() . "assets/icons/003-male-2.svg";

			if (isset($_POST['avatar_temp'])) {
				$_SESSION['avatarMadeAccount'] = $_POST['avatar_temp'];
			} else {
				$_SESSION['avatarMadeAccount'] = "assets/icons/003-male-2.svg";
			}

			$data['addBtnTitle'] = $this->lang->line('add_btn_cg_title');
			$data['cancelBtnTitle'] = $this->lang->line('cancel_btn_title');

			$data = array_merge($data, $this->getNameLabels());

			$data['warningmessage'] = "";

			$this->parse_header($title);
			$this->parser->parse('signup', $data);
			$this->parse_footer($data);
		}
	}

	public function signupuser()
	{
		$this->checkIfLoggedIn();

		$username = ($this->input->post('username'));
		$password = ($this->input->post('password'));
		$firstname = ($this->input->post('firstname'));
		$lastname = ($this->input->post('lastname'));
		$email = ($this->input->post('email'));
		$adminfct = ($this->input->post('admin'));
		$avatar = $_SESSION['avatarMadeAccount'];

		$username = htmlspecialchars($username, ENT_QUOTES);
		$password = htmlspecialchars($password, ENT_QUOTES);
		$firstname = htmlspecialchars($firstname, ENT_QUOTES);
		$lastname = htmlspecialchars($lastname, ENT_QUOTES);
		$email = htmlspecialchars($email, ENT_QUOTES);
		$adminfct = htmlspecialchars($adminfct, ENT_QUOTES);
		$avatar = htmlspecialchars($avatar, ENT_QUOTES);

		$admin='0';
		if ($adminfct)
			$admin = '1';

		$data = array(
			'lastname' => $lastname,
			'firstname' => $firstname,
			'username' => $username,
			'password' => $password,
			'iddepartment' => '1',
			'admin' => $admin,
			'email' => $email,
			'avatar' => $avatar
		);

		if(!empty($username) && !empty($password) && !empty($firstname) && !empty($lastname) && !empty($email)){
			$errors = $this->Login_model->signupusers($data);

			$username_exists = $errors['username_exists'];
			$successful = $errors['successful'];

			if($username_exists) {
				$data['alertfct']="danger";
				$data['warningmessage'] = $this->lang->line('username_warning_message');
			}
			else if($successful){
				$data['alertfct']="success";
				$data['warningmessage'] = $this->lang->line('username_success_message');
				$url = base_url()."index.php/Controller/home";
				header('Refresh: 3; URL = home');
			}
		}

		$title = $this->lang->line('signup_title_tab');
		$data['linkCheckById'] = "signup";
		$data['title_h1'] = $this->lang->line('add_new_user');
		$data['formactionLink']="signupuser";

		$data['addBtnTitle'] = $this->lang->line('add_btn_cg_title');
		$data['cancelBtnTitle'] = $this->lang->line('cancel_btn_title');

		$data=array_merge($data, $this->getActivetab("manage"));

		$data['accountAvatar'] = base_url().$avatar;

		$data = array_merge($data, $this->getNameLabels());

		$this->parse_header($title);
		$this->parser->parse('signup',$data);
		$this->parse_footer($data);
	}

	public function saveResidentFunction() {
		$this->checkIfLoggedIn();
		$firstName = ($this->input->post('firstName'));
		$lastName = ($this->input->post('lastName'));
		$roomNumber = ($this->input->post('roomNumber'));
		$birthYear = ($this->input->post('birthYear'));
		$gender = ($this->input->post('gender'));

		$firstName = htmlspecialchars($firstName, ENT_QUOTES);
		$lastName = htmlspecialchars($lastName, ENT_QUOTES);
		$roomNumber = htmlspecialchars($roomNumber, ENT_QUOTES);
		$birthYear = htmlspecialchars($birthYear, ENT_QUOTES);
		$gender = htmlspecialchars($gender, ENT_QUOTES);

		if(isset($_SESSION['signature_url'])){
			$signature = $_SESSION['signature_url'];
		}
		else{
			$signature = NULL;
		}


		$resident = array(
			'name' => $lastName,
			'firstname' => $firstName,
			'roomnr' => $roomNumber,
			'birthyear' => $birthYear,
			'active' => '1',
			'gender' => $gender,
			'iddepartment' => '1',
			'signature' => $signature
		);

		if(!empty($lastName) && !empty($firstName) && !empty($roomNumber) && !empty($birthYear) && !empty($gender)) {
			$_SESSION['residentid'] = $this->Resident_form_model->pushFormData($resident);
		}
	}

	public function logout(){
		unset($_SESSION['user_id']);
		if(isset($_SESSION['surveydone'])){
			unset($_SESSION['surveydone']);
			$this->load->model('searchResidents_model');
			$row = $this->searchResidents_model->getResidentName($_SESSION["residentid"]);
			$data['resident_name'] = $row->firstname;
			$data['warningmessage'] = "Bedankt om de vragenlijst in te vullen ".$data['resident_name'].". Je mag nu de tablet teruggeven. Nog een fijne dag!";
		}
		else{
			$data['warningmessage'] = "You're logged out. Thank you, come again!";
		}

		session_destroy();

		$data['page_title'] = "Login | UXWD NH Survey";
		$data['alertfct']="info";
		$this->parser->parse('login',$data);

	}

	//editAccountFunction needs to public to make the ajax call done in the script possible
	public function editAccountFunction() {
		$data = $this->getActivetab("manage");
		$this->checkIfLoggedIn();
		$title = $this->lang->line('editAccount_title_tab');
		$data['linkCheckById'] = "editAccountFunction";
		$data['title_h1'] = $this->lang->line('edit_user');
		$data['formactionLink']= "saveUpdatedAccount";
		$data['warningmessage'] = $_SESSION['warningMessage'];
		$data['alertfct'] = $_SESSION['alertfct'];
		$data['modalLink'] = "updatePassword";

		$caregiverInfo = $this->Database_model->get_name($_SESSION['user_id']);
		$adminTrueFalse = $caregiverInfo['adminFunction'];
		if($adminTrueFalse == 0) {
			$data['hidden'] = "hidden";
		}
		else{
			$data['hidden'] = "";
		}

		$data = array_merge($data,$this->getNameLabels());
		$data['modalPasswordTitle'] = $this->lang->line('modal_password_title');
		$data['oldPassword'] = $this->lang->line('old_password');
		$data['newPassword'] = $this->lang->line('new_password');

		$data['btn_edit_account'] = $this->lang->line('btn_edit_account');
		$data['btn_password'] = $this->lang->line('btn_password');

		$data['saveBtnTitle'] = $this->lang->line('save_btn_title');
		$data['cancelBtnTitle'] = $this->lang->line('cancel_btn_title');
		$data['passwordBtnTitle'] = $this->lang->line('change_password_title');

		$row = $this->Login_model->getAccountData($_SESSION["user_id"]);

		$data['lastNameField'] = $row->name;
		$data['firstNameField'] = $row->firstname;
		$data['usernameField'] = $row->username;
		//$data['password'] = $row->password;
		$adminFunction = $row->adminfunction;
		$data['emailField'] = $row->email;
		$data['accountAvatar'] = base_url().$row->avatar;

		if($adminFunction == 1) {
			$data['checkedAdmin'] = "checked";
		} else {
			$data['checkedAdmin'] = "";
		}

		if(isset($_POST['avatar_temp'])) {
			$_SESSION['avatar_temp'] = $_POST['avatar_temp'];
		}
		else{
			$_SESSION['avatar_temp'] = $row->avatar;
		}
		//echo "avatar_temp: ".$_SESSION['avatar_temp']."<br>";

		if(isset($_POST['avatar'])) {
			$_SESSION['avatar'] = $_POST['avatar'];
		} else {
			$_SESSION['avatar'] = $row->avatar;
		}
		//echo "avatar: ".$_SESSION['avatar'];

		$_SESSION['username'] = $row->username;

		$this->parse_header($title);
		$this->parser->parse('edit_account',$data);
		$this->parse_footer($data);
	}

	public function saveUpdatedAccount() {
		$username = ($this->input->post('username'));
		//$password = ($this->input->post('password'));
		$firstName = ($this->input->post('firstName'));
		$lastName = ($this->input->post('lastName'));
		$email = ($this->input->post('email'));
		$adminfct = ($this->input->post('admin'));
		$avatar = $_SESSION['avatar_temp'];
		$_SESSION['avatar'] = $avatar;

		$username = htmlspecialchars($username, ENT_QUOTES);
		$firstName = htmlspecialchars($firstName, ENT_QUOTES);
		$lastName = htmlspecialchars($lastName, ENT_QUOTES);
		$email = htmlspecialchars($email, ENT_QUOTES);
		$adminfct = htmlspecialchars($adminfct, ENT_QUOTES);

		//echo "avatar saveUpdatedAccount: ".$avatar."<br>";

		unset($_SESSION['avatar_temp']);

		$admin='0';
		if ($adminfct)
			$admin = '1';

		$data = array(
			'name' => $lastName,
			'firstname' => $firstName,
			'username' => $username,
			//'password' => $password,
			'iddepartment' => '1',
			'adminfunction' => $admin,
			'email' => $email,
			'avatar' => $avatar
		);

		$errors = $this->Login_model->updateAccountData($data);

		$username_exists = $errors['username_exists'];
		$successful = $errors['successful'];

		if($username_exists) {
			$_SESSION['alertfct'] = "danger";
			$_SESSION['warningMessage'] = $this->lang->line('username_warning_message');
		}
		else if($successful){
			$_SESSION['alertfct'] = "success";
			$_SESSION['warningMessage'] = $this->lang->line('username_edit_success_message');
			$url = base_url()."index.php/Controller/home";
			header('Refresh: 3; URL = home');
		}

		$this->editAccountFunction();
	}


	public function editAccount() {
		$_SESSION['warningMessage'] = "";
		$_SESSION['alertfct'] = "";

		$this->editAccountFunction();
	}

	public function updatePassword() {
		if (isset($_POST['oldPassword']) && isset($_POST['newPassword'])) {
			$newPassword = $_POST['newPassword'];
			$oldPassword = $_POST['oldPassword'];
			if ($this->Login_model->checkAccountPassword($oldPassword) == 0) {
				$_SESSION['alertfct'] = "danger";
				$_SESSION['warningMessage'] = $this->lang->line('password_warning_message');
				$this->editAccountFunction();
			} else {
				$this->Login_model->updateAccountPassword($newPassword);
				$_SESSION['alertfct'] = "success";
				$_SESSION['warningMessage'] = $this->lang->line('password_correct_message');
				$this->editAccountFunction();
			}
		}
	}


	/* -.-.-.-.-.- CAREGIVER FUNCTIONS -.-.-.-..- */

	public function home(){
		$this->index();
	}

	public function manage() {
		$title = $this->lang->line('manage_title_tab');
		$data = $this->getActivetab("manage");
		$data['hide-home'] = "hidden";
		$data['hide-manage'] = "";

		$data['results'] = $this->lang->line('results');
		$data['residents'] = $this->lang->line('residents');
		$data['lottery'] = $this->lang->line('lottery');

		$data['resultsTitle'] = $this->lang->line('results_title');
		$data['residentsTitle'] = $this->lang->line('residents_title');;
		$data['lotteryTitle'] = $this->lang->line('lottery_title');;

		$this->parse_header($title);
		$this->parser->parse('hometemplate',$data);
		$this->parse_footer($data);
	}


	/* -.-.-.-.-.- EDITING RESIDENTS FUNCTIONS -.-.-.-..- */
	public function saveResident() {
		$this->checkIfLoggedIn();
		$this->saveResidentFunction();
		$this->manageResident();
	}

	public function saveResidentSurvey() {
		$this->checkIfLoggedIn();
		$this->saveResidentFunction();
		$this->firstSignSurvey();
	}

	public function saveEditResident() {
		$this->checkIfLoggedIn();
		$firstName = ($this->input->post('firstName'));
		$lastName = ($this->input->post('lastName'));
		$roomNumber = ($this->input->post('roomNumber'));
		$birthYear = ($this->input->post('birthYear'));
		$gender = ($this->input->post('gender'));
		$activeState = ($this->input->post('(non)active'));

		$firstName = htmlspecialchars($firstName, ENT_QUOTES);
		$lastName = htmlspecialchars($lastName, ENT_QUOTES);
		$roomNumber = htmlspecialchars($roomNumber, ENT_QUOTES);
		$birthYear = htmlspecialchars($birthYear, ENT_QUOTES);


		$resident = array(
			'name' => $lastName,
			'firstname' => $firstName,
			'roomnr' => $roomNumber,
			'birthyear' => $birthYear,
			'active' => $activeState,
			'gender' => $gender,
		);

		$this->Resident_form_model->updateFormData($resident, $_SESSION['residentid']);
		$this->manageResident();
	}

	public function editResident() {
		$title = $this->lang->line('editResident_title_tab');
		$data = $this->getActivetab("manage");
		$data['title_h1'] = $this->lang->line('title_edit_resident');
		$data['btn_name'] = $this->lang->line('save');
		//$data['title'] = "Bewaar wijzigingen";
		//$data['navBarSurvey'] = $data['navBarHome'] = 'font-weight-light btn-secondary';
		//$data['navBarData'] = 'font-weight-bold w3-red';
		$data['saveLink'] = 'saveEditResident';
		$data['signature_btn'] = $this->lang->line('signature_btn');

		$data['saveBtnTitle'] = $this->lang->line('save_btn_title');
		$data['cancelBtnTitle'] = $this->lang->line('cancel_btn_title');
		$data['maleBtnTitle'] = $this->lang->line('male_btn_title');
		$data['femaleBtnTitle'] = $this->lang->line('female_btn_title');
		$data['activeBtnTitle'] = $this->lang->line('active_btn_title');
		$data['nonactiveBtnTitle'] = $this->lang->line('nonactive_btn_title');
		$data['signatureBtnTitle'] = $this->lang->line('signature_btn_title');

		$signatureSet = $this->Resident_form_model->getIfSignatureSet($_SESSION["residentid"]);
		if($signatureSet == 0) {
			$data['hidden'] = "";
		} else {
			$data['hidden'] = "hidden";
		}

		$row = $this->Resident_form_model->getFormData($_SESSION["residentid"]);

		$data['lastName'] = $row->name;
		$data['firstName'] = $row->firstname;
		$data['birthYear'] = $row->birthyear;
		$data['roomNumber'] = $row->roomnr;
		$gender = $row->gender;
		$activeState = $row->active;

		if($gender == "male") {
			$data['genderMale'] = "active";
			$data['genderFemale'] = "";
			$data['checkedMale'] = "checked";
			$data['checkedFemale'] = "";
		}
		else {
			$data['genderMale'] = "";
			$data['genderFemale'] = "active";
			$data['checkedMale'] = "";
			$data['checkedFemale'] = "checked";
		}

		if($activeState == "1") {
			$data['activeState'] = "active";
			$data['nonactiveState'] = "";
			$data['checkedActive'] = "checked";
			$data['checkedNonactive'] = "";
		}
		else {
			$data['activeState'] = "";
			$data['nonactiveState'] = "active";
			$data['checkedActive'] = "";
			$data['checkedNonactive'] = "checked";
		}

		$data=array_merge($data, $this->getActivetab("manage"));
		$data=array_merge($data, $this->getNameLabels());


		$this->parse_header($title);
		$this->parser->parse('edit_resident_form', $data);
		$this->parse_footer($data);
	}

	public function setResidentId() {	//used by table script to start survey
		$_SESSION["residentid"] = $_GET['res'];
	}

	public function addResident() {
		$title = $this->lang->line('addResident_title_tab');
		$data = $this->getActivetab("manage");
		$data['title_h1'] = $this->lang->line('title_add_resident');
		$data['btn_name'] = $this->lang->line('btn_add');
		$data['link'] = 'manageResident';
		$data['title'] = "Voeg een resident toe";
		$data['navBarSurvey'] = $data['navBarHome'] = 'font-weight-light btn-secondary';
		$data['navBarData'] = 'font-weight-bold w3-red';
		$data['saveLink'] = 'saveResident';
		$data['backLink'] = 'manageResident';

		$data['addStartBtnTitle'] = $this->lang->line('add_resident_title');
		$data['cancelBtnTitle'] = $this->lang->line('cancel_btn_title');
		$data['maleBtnTitle'] = $this->lang->line('male_btn_title');
		$data['femaleBtnTitle'] = $this->lang->line('female_btn_title');

		$data = array_merge($data, $this->getColorBtn("primary"));
		$data = array_merge($data, $this->getNameLabels());

		$this->parse_header($title);
		$this->parser->parse('resident_form_template', $data);
		$this->parse_footer($data);
	}

	public function saveSignature(){
		$result = array();
		$imagedata = base64_decode($_POST['img_data']);
		$filename = md5(date("dmYhisA"));
		//Location to where you want to created sign image
		$file_name = './assets/doc_signs/'.$filename.'.png';
		//$file_name = 'http://localhost:8888/a19ux5/assets/doc_signs/'.$filename.'.png';
		file_put_contents($file_name,$imagedata);
		$result['status'] = 1;
		$result['file_name'] = $file_name;
		$url='./assets/doc_signs/'.$filename.'.png';
		$result['url'] = $url;
		return $result;
	}

	public function firstSignManage() {
		$title = $this->lang->line('firstSign_title_tab');
		$data = $this->getActivetab("manage");
		$data['link'] = 'signaturePageManage';
		$data['cancel_link'] = 'editResident';

		$data = array_merge($this->getColorBtn("primary"), $data);
		$data = array_merge($this->firstSignParser(), $data);

		$this->parse_header($title);
		$this->parser->parse('signature_yes_no', $data);
		$this->parse_footer($data);
	}

	public function firstSignSurvey() {
		$title = $this->lang->line('firstSign_title_tab');
		$data = $this->getActivetab("survey");
		$data['link'] = 'signaturePageSurvey';
		$data['cancel_link'] = 'selectResident';

		$data = array_merge($this->getColorBtn("secondary"), $data);
		$data = array_merge($this->firstSignParser(), $data);

		$this->parse_header($title);
		$this->parser->parse('signature_yes_no', $data);
		$this->parse_footer($data);
	}

	public function addResidentSurvey() {
		$data = $this->getActivetab("survey");
		$title = $this->lang->line('addResident_title_tab');
		$data['title_h1'] = $this->lang->line('title_add_resident');
		$data['btn_name'] = $this->lang->line('btn_start');
		$data['link'] = 'firstSignSurvey';
		$data['addStartBtnTitle'] = $this->lang->line('start_survey_title');
		$data['cancelBtnTitle'] = $this->lang->line('cancel_btn_title');
		$data['maleBtnTitle'] = $this->lang->line('male_btn_title');
		$data['femaleBtnTitle'] = $this->lang->line('female_btn_title');

		$data['saveLink'] = 'saveResidentSurvey';
		$data['backLink'] = 'home';

		$data = array_merge($data, $this->getColorBtn("secondary"));

		$data = array_merge($data, $this->getNameLabels());

		$this->parse_header($title);
		$this->parser->parse('resident_form_template', $data);
		$this->parse_footer($data);
	}


	public function selectResident()
	{
		$data = $this->getActivetab("survey");
		$title = $this->lang->line('selectResident_title_tab');
		$data['title_h1'] = $this->lang->line('title_select_resident');
		$data['add_btn_name'] = $this->lang->line('btn_add_resident');
		$data['add_link'] = 'addResidentSurvey';
		$data['add_title'] = $this->lang->line('add_btn_title');
		$data['start_btn_name'] = $this->lang->line('btn_start');
		$data['start_link'] = 'setSignature';
		$data['start_title'] = "Start de nieuwe enquete";

		$data['nameLabel'] = $this->lang->line('name');
		$data['roomNumberLabel'] = $this->lang->line('room_number');
		$data['latestLabel'] = $this->lang->line('latest');
		$data['residentLabel'] = $this->lang->line('resident_label');
		$data['residentFieldLabel'] = $this->lang->line('resident_field_label');

		$data['ordertype'] = 0;

		$data = array_merge($data, $this->getColorBtn("secondaryinv"));

		$data = array_merge($data,$this->getTableLabels());

		$this->parse_header($title);
		$this->parser->parse('manageResidents', $data);
		$this->parse_footer($data);
	}


	public function manageResident()
	{
		$title = $this->lang->line('selectResident_title_tab');
		$data['title_h1'] = $this->lang->line('title_manage_resident');
		$data['add_btn_name'] = $this->lang->line('btn_add_resident');
		$data['add_link'] = 'addResident';
		$data['add_title'] = $this->lang->line('add_btn_title');
		$data['start_btn_name'] = $this->lang->line('btn_edit_resident');
		$data['start_link'] = 'editResident';
		$data['start_title'] = "Bewerk";
		$data['residentLabel'] = $this->lang->line('resident_label');
		$data['residentFieldLabel'] = $this->lang->line('resident_field_label');

		$data['show_allInactive']=$this->lang->line('show_allInactive');
		$data['show_allWOSig']=$this->lang->line('show_allWOSig');
		$data['nameLabel'] = $this->lang->line('name');
		$data['roomNumberLabel'] = $this->lang->line('room_number');
		$data['latestLabel'] = $this->lang->line('latest');

		$data['ordertype'] = 1;


		$data=array_merge($data, $this->getActivetab("manage"));

		$data = array_merge($data, $this->getColorBtn("primaryinv"));

		$data = array_merge($data,$this->getTableLabels());

		$this->parse_header($title);
		$this->parser->parse('manageResidents', $data);
		$this->parse_footer($data);
	}

	public function liveSearch(){
		$q = $_GET['q'];
		$orderType = $_GET['int'];
		$isChecked = $_GET['box'];
		$isSignatureChecked = $_GET['sigbox'];
		$this->load->model('SearchResidents_model');
		if($orderType==3){ //for the results page
			$this->SearchResidents_model->fillTableNonAnon($q);
		}
		else{ //select resident pages
			$this->SearchResidents_model->fillTable($q, $orderType, $isChecked,$isSignatureChecked);
		}
	}

	/* -.-.-.-.-.- LOTTERY FUNCTIONS -.-.-.-..- */
	public function lottery() {
		$title = $this->lang->line('lottery_title_tab');
		$data = $this->getActivetab("manage");
		$data['title_h1'] = $this->lang->line('title_lottery');
		$data['btn_name'] = $this->lang->line('btn_lottery');
		$data['link'] = 'lotterywinner';

		$data['last_week'] = $this->lang->line('last_week');
		$data['last_month'] = $this->lang->line('last_month');
		$data['last_half_year'] = $this->lang->line('last_half_year');
		$data['last_year'] = $this->lang->line('last_year');
		$data['lotteryBtnTitle'] = $this->lang->line('lottery_btn_title');

		$this->parse_header($title);
		$this->parser->parse('lottery', $data);
		$this->parse_footer($data);
	}

	public function lotterywinner() {
		$timerange = ($this->input->post('timerange'));
		$title = $this->lang->line('lottery_success_title_tab');
		$data = $this->getActivetab("manage");
		$data['title_h1'] = $this->lang->line('title_lotterywinner');

		$this->parse_header($title);
		if(!empty($timerange)){
			$data['winner']=$this->Database_model->getWinner($timerange);
			$this->parser->parse('lotterywinner', $data);
		}
		else{
			$this->parser->parse('lottery',$data);
		}
		$this->parse_footer($data);
	}


	/* -.-.-.-.-.- CHARTS FUNCTIONS -.-.-.-..- */
	public function charts(){
		$title = $this->lang->line('charts_title_tab');

		$scores = $this->Database_model->get_averages();
		$data = $this->getActivetab("manage");
		$data['scoresOverview'] = $scores;

		$data['scoresProgress_month'] = $this->Database_model->get_timevalues("-1 month");
		$data['scoresProgress_3months'] = $this->Database_model->get_timevalues("-3 month");
		$data['scoresProgress_halfyear'] = $this->Database_model->get_timevalues("-6 month");
		$data['scoresProgress_year'] = $this->Database_model->get_timevalues("-1 year");

		$data['charttitlecategory']= "";

		$data['residentLabel'] = $this->lang->line('resident_label');
		$data['residentFieldLabel'] = $this->lang->line('resident_field_label');
		$data['nameLabel'] = $this->lang->line('name');
		$data['roomNumberLabel'] = $this->lang->line('room_number');
		$data['latestLabel'] = $this->lang->line('latest');

		$stacked = $this->Database_model->get_stackedoverview();
		$data['scoresstacked']= $stacked;

		$data['start_link'] = 'chartsindividual';
		$data['ordertype'] = 3;

		$data = array_merge($data,$this->getColorBtn("primaryinv"));
		$data = array_merge($data,$this->getTableLabels());
		$data = array_merge($data,$this->getGraphsLabels());
		$data = array_merge($data,$this->getChartsButtonLabels());

		$this->parse_header($title);
		$this->parser->parse('charttabs', $data);
		$this->parse_footer($data);
	}

	public function chartscategory(){
		$category = ($this->input->post('category'));
		if(!empty($category)){
			$data = $this->getActivetab("manage");
			$scores = $this->Database_model->get_categoryavg($category);
			$data['scoresOverviewCategory'] = $scores;
			$data['category'] = $category;
			$data['chartcat_title_h1'] = $this->lang->line('chartcat_title_h1').$category;

			$data['scoresProgress_month'] = $this->Database_model->get_timevaluescategory("-1 month",$category);
			$data['scoresProgress_3months'] = $this->Database_model->get_timevaluescategory("-3 month",$category);
			$data['scoresProgress_halfyear'] = $this->Database_model->get_timevaluescategory("-6 month",$category);
			$data['scoresProgress_year'] = $this->Database_model->get_timevaluescategory("-1 year",$category);

			$data['charttitlecategory']= $this->lang->line('charttitleProgCategory').$category;

			$data['btnbacktoresident']="none";

			$data=array_merge($data,$this->getGraphsLabels());

			$stacked = $this->Database_model->get_stacked($category);
			$data['scoresstacked']= $stacked;

			$data = array_merge($data,$this->getChartsButtonLabels());

			$title = $this->lang->line('chartscategory_title_tab').$category." | UXWD NH Survey";
			$this->parse_header($title);
			$this->parser->parse('charttabscategory', $data);
			$this->parse_footer($data);
		}
		else{
			echo "Error: category not set!";
		}
	}

	public function chartsindividual(){

		$data = $this->getActivetab("manage");
		$residentid = $_SESSION["residentid"];
		$scores = $this->Database_model->get_individualavg($residentid);
		$data['scoresOverview'] = $scores;
		$this->load->model('searchResidents_model');
		$resname = $this->searchResidents_model->getResidentName($_SESSION["residentid"]);
		$data['resident_name'] = $resname->firstname." ".$resname->name;
		$data['chartind_title_h1'] = $this->lang->line('chartind_title_h1') . $data['resident_name'];

		$data=array_merge($data,$this->getGraphsLabels());

		$data['scoresProgress_month'] = $this->Database_model->get_timevaluesind("-1 month",$residentid);
		$data['scoresProgress_3months'] = $this->Database_model->get_timevaluesind("-3 month",$residentid);
		$data['scoresProgress_halfyear'] = $this->Database_model->get_timevaluesind("-6 month",$residentid);
		$data['scoresProgress_year'] = $this->Database_model->get_timevaluesind("-1 year",$residentid);

		$data['charttitlecategory']= "(".$data['resident_name'].")";

		$data = array_merge($data,$this->getChartsButtonLabels());

		$title = $this->lang->line('chartscategory_title_tab').$data['resident_name']." | UXWD NH Survey";
		$this->parse_header($title);
		$this->parser->parse('chartindividual', $data);
		$this->parse_footer($data);
	}

	public function chartsindcategory(){
		$residentid = $_SESSION["residentid"];
		$data = $this->getActivetab("manage");
		$data = array_merge($data,$this->getGraphsLabels());
		$this->load->model('searchResidents_model');
		$resname = $this->searchResidents_model->getResidentName($_SESSION["residentid"]);
		$data['resident_name'] = $resname->firstname." ".$resname->name;
		$category = ($this->input->post('category'));
		if(!empty($category)){
			$data['scoresOverviewCategory'] = $this->Database_model->get_indcategoryavg($category,$residentid);
			$data['category'] = $category;
			$data['chartcat_title_h1'] = $data['resident_name'].": ".$this->lang->line('chartcat_title_h1')."'".$category."'";

			$data['scoresProgress_month'] = $this->Database_model->get_timevaluesindcat("-1 month",$residentid,$category);
			$data['scoresProgress_3months'] = $this->Database_model->get_timevaluesindcat("-3 month",$residentid,$category);
			$data['scoresProgress_halfyear'] = $this->Database_model->get_timevaluesindcat("-6 month",$residentid,$category);
			$data['scoresProgress_year'] = $this->Database_model->get_timevaluesindcat("-1 year",$residentid,$category);
			$data['charttitlecategory']= $this->lang->line('charttitleProgInd').$data['resident_name']." ".$this->lang->line('charttitleProgCategory').$category;

			$data['personBtnTitle'] = $this->lang->line('person_btn_title');

			$data['charts_stacktitle']=$data['resident_name'].": ".$this->lang->line('charts_stacktitle');
			$data['backToIndLevel']="Ga terug naar overzicht van ".$data['resident_name'];
			$data['btnbacktoresident']="";

			$data['charttitleOverview_cattab'] = $data['resident_name'].": ".$this->lang->line('charttitleOverviewCat');

			$stacked = $this->Database_model->get_stackedindcat($residentid,$category);
			$data['scoresstacked']= $stacked;

			$data = array_merge($data,$this->getChartsButtonLabels());

			$title = $this->lang->line('chartscategory_title_tab').$category." | UXWD NH Survey";
			$this->parse_header($title);
			$this->parser->parse('charttabscategory', $data);
			$this->parse_footer($data);
		}
		else{
			echo "Error: category not set!";
		}
	}


	/* -.-.-.-.-.- SURVEY FUNCTIONS -.-.-.-..- */

	public function setAnonymous(){

		/*if ($this->input->post('radioButtonAno') == 1){
			$_SESSION['anonymous'] = true;
		}
		else {
			$_SESSION['anonymous'] = false;
		}*/
		$anonymous=$this->input->post('radioButtonAno');
		$this->Database_model->newsurvey($anonymous);
		$this->question();
	}

	public function question()
	{
		$data = $this->getTomAnonymous();

		//$id=$this->Database_model->getsurveyid();
		//echo $id;

		$data['pagetitle'] = "Vragenlijst vraag";

			if ($_SESSION['count'] % 3) {


				if (1 <= $_SESSION['idQu'] && $_SESSION['idQu'] <= 52) {


					$currentanswer= $this->Database_model->get_current_question_answer();


					/*if ($this->input->post('next')&& $this->input->post('radioButton'))
					{

						$answer=$previousanswer;
					    $this->Database_model->write_answer($answer);
						$_SESSION['idQu'] = $_SESSION['idQu'] + 1;
					}*/






					if ($this->input->post('next')&& $this->input->post('radioButton'))
					{//&& $this->input->post('radioButton')
						$questionData = $this->Database_model->get_question_data();
						$nextquestionData = $this->Database_model->get_next_question_data();
						$currentcategory = $questionData['category'];
						$nextcategory = $nextquestionData['category'];


						if ($currentcategory != $nextcategory) {
							$_SESSION['count'] = $_SESSION['count'] + 1;
						}

						$answer=$this->input->post('radioButton');
						$this->Database_model->write_answer($answer);

						if($_SESSION['idQu']==52)
						{

							$_SESSION['count']=1;
							$_SESSION['idQu']=1;
							$this->signature();
							return;
						}

						$_SESSION['idQu'] = $_SESSION['idQu'] + 1;

					}
					else
					{
						if($this->input->post('next'))
					   {
						$answer=$currentanswer;
						$this->Database_model->write_answer($answer);
						$_SESSION['idQu'] = $_SESSION['idQu'] + 1;
					}


					}


					if ($this->input->post('previous')) {

						$data['previous_answer'] = $this->Database_model->get_previous_question_answer();
						$_SESSION['idQu'] = $_SESSION['idQu'] - 1;
						if($_SESSION['idQu']<1)
						{
							$this->welcomeAnonymous();
							$_SESSION['idQu']=1;
							$_SESSION['count']=1;
							return;
						}

					}
				}
	          	else {
					$_SESSION['idQu'] = 1;
				}


			$questionData = $this->Database_model->get_question_data();
			$data['total'] = $questionData['number'];
			$data['id'] = $questionData['categoryid'];
			$data['percent'] = ($questionData['categoryid'] / $questionData['number']) * 100;
			$data['category'] = $questionData['category'];//. ": "
			$data['tom_text'] = $questionData['question'];
			$dataModal['signature_link']="signature";
			$this->parser->parse('exit_survey_modal', $dataModal);
			$this->parser->parse('progressbar', $data);

			}

			else {

				if (1 <= $_SESSION['idQu'] && $_SESSION['idQu'] <= 52) {

					$answer=$this->input->post('radioButton');
					$this->Database_model->write_answer($answer);}


				$this->game();
			}


	    /* $questionData = $this->Database_model->get_question_data();
			$nextquestionData = $this->Database_model->get_next_question_data();
			$currentcategory = $questionData['category'];
			$nextcategory = $nextquestionData['category'];

			if ($currentcategory != $nextcategory) {
				$_SESSION['count'] = $_SESSION['count'];
			}*/


	}

	public function setSignature() {
		$signatureSet = $this->Resident_form_model->getIfSignatureSet($_SESSION["residentid"]);
		if($signatureSet == 0) {
			$this->firstSignSurvey();
			/*$data['tom_text'] = "Gelieve hier even je handtekening te zetten zodat we deze kunnen opslagen. Hiermee kunnen we later bewijzen dat jouw vragenlijst ook echt van jou is.";
			$data['tom_pic']=base_url()."assets/images/tom_1.png";
			$data['tom_gif']=base_url()."assets/images/tom_gif.gif";
			$data['next_link'] = 'welcomeScreen';
			$this->parser->parse('first_signature', $data);*/
		}
		else{
			$this->welcomeScreen();
		}

	}

	public function welcomeScreen()
	{
		$this->load->model('searchResidents_model');
		$this->checkIfLoggedIn();
		$data['back_link'] = 'selectResident';
		$data['start_link'] = 'welcomeAnonymous';
		$data['caregivername'] = $this->getCaregiverName();
		$row = $this->searchResidents_model->getResidentName($_SESSION["residentid"]);
		$data['resident_name'] = $row->firstname;
		$data['tom_text'] = "Hey " . $data['resident_name'] . ", blij je te zien! Klaar om een vragenlijst in te vullen? Als dit niet is wat je wil, geef de tablet dan terug aan " . $data['caregivername'] . ". Heb je graag dat ik je nog eens uitleg hoe alles werkt of wil je liever meteen beginnen?";
		$data['tom_pic']=base_url()."assets/images/tom_1.png";
		$data['tom_gif']=base_url()."assets/images/tom_gif.gif";
		$data['pagetitle'] = "Start met de vragenlijst";
		$dataModal['signature_link']="logout";
		$this->parser->parse('question_welcome_screen', $data);
		$this->parser->parse('exit_survey_modal', $dataModal);
	}
	public function welcomeAnonymous()
	{
		$data['start_link'] = 'setAnonymous';
		$data['caregivername'] = $this->getCaregiverName();
		$data['tom_text']="Alvorens er echt aan te beginnen wil ik nog weten of je de vragen anoniem invult of niet. Wanneer je niet anoniem invult, kan ".$data['caregivername'].
			" je antwoorden zien achteraf.";
		$data['tom_pic']=base_url()."assets/images/tom_1.png";
		$data['tom_gif']=base_url()."assets/images/tom_gif.gif";
		$data['tom_anon_pic']=base_url()."assets/images/tom_ano1.png";
		$data['tom_anon_gif']=base_url()."assets/images/tom_ano_gif.gif";
		$_SESSION['idQu']=1;
		$_SESSION['count']=1;
		$_SESSION['finish']=0;
		$data['pagetitle'] ="Vragenlijst anoniem?";
		$dataModal['signature_link']="logout";
		$this->parser->parse('exit_survey_modal', $dataModal);
		$this->parser->parse('question_anonymous_screen',$data);
	}

	public function game() {
		$data['link'] = "between_questionsrounds";
		$data['tom_text_memory']="Tijd voor ontspanning! Vind twee dezelfde dieren door op de kaartjes te klikken om de achtergrond vrij te spelen.";
		$data['pagetitle'] ="Vragenlijst memory spel";
		$data['nextbtnname']="OVERSLAAN";
		$data['memGameScript'] = base_url()."assets/styling/js/memGameScript.js";
		$data['nextbtnicon']="067-next.svg";
		$this->parser->parse('memory_game',$data);
	}

	public function lastpagepicture() {
		$data['link'] = "logout";
		$this->load->model('searchResidents_model');
		$row = $this->searchResidents_model->getResidentName($_SESSION["residentid"]);
		$data['resident_name'] = $row->firstname;
		$data['tom_text_memory']="Vragenlijst ingevuld, goed gedaan ".$data['resident_name']."! Hier kan je nog eens kijken naar de achtergrondfoto van het memoryspel. Nog een fijne dag!";
		$data['pagetitle'] ="Einde van de vragenlijst";
		$data['nextbtnname']="AFRONDEN";
		$data['memGameScript'] = "";
		$data['nextbtnicon']="073-finish.svg";
		$this->parser->parse('memory_game',$data);
	}

	public function between_questionsrounds() {

		$data = $this->getTomAnonymous();

		//$_SESSION['finish']=$_SESSION['finish']+2;//2
		//$_SESSION['count']=$_SESSION['count']+1;//1
		//$_SESSION['idQu']=$_SESSION['idQu']+1;//1

		$data['percent']=($_SESSION['idQu']*100)/52;
		$data['next_link'] = 'question';
		$data['stop_link'] = 'signature';
		$data['finished']=$_SESSION['finish'];
		$nextquestionData=$this->Database_model->get_next_question_data();
		$data['nextcategory']=$nextquestionData['category'];
		$data['tom_text']="Weer een onderwerp ingevuld, bedankt! Je kan deze vragenlijst nu stoppen als je wil. Indien je verder wil gaan,	starten we nu aan de vragenronde '".$data['nextcategory']."'. Goed bezig!";
		$data['pagetitle'] ="Vragenlijst onderwerp afgerond";
		$this->parser->parse('question_between_topics',$data);
	}


	public function signature()
	{
		$data = $this->getTomAnonymous();
		$id=$this->Database_model->getsurveyid();
		$_SESSION['surveydone']=1;
		$this->load->model('searchResidents_model');
		$row = $this->searchResidents_model->getResidentName($_SESSION["residentid"]);
		$data['resident_name'] = $row->firstname;
		$data['next_link'] = 'lastpagepicture';
		$data['pagetitle'] = "Vragenlijst klaar handtekenen";
		$data['tom_text']="Dankje ".$data['resident_name'].", dit is het einde van de vragenlijst. Dat ging vlot! Zou je nu nog willen handtekenen? Zo weet ik dat jij het was. Bovendien maak je zo kans op de volgende loterij!";
		$this->parser->parse('question_signature',$data);
	}

	public function saveSign()
	{
		$result = $this->saveSignature();
		$this->Database_model->sign($result['url']);
		echo json_encode($result);
	}


	public function saveFirstSign() {
		$result = $this->saveSignature();
		$this->Database_model->firstSign($result['url']);
		$_SESSION['signature_url'] = $result['url'];
		echo json_encode($result);
	}

	public function signaturePageSurvey() {
		$data = $this->getTom();
		$data['next_link'] = 'welcomeScreen';
		$this->load->model('searchResidents_model');
		$row = $this->searchResidents_model->getResidentName($_SESSION["residentid"]);
		$data['resident_name'] = $row->firstname;
		$data['tom_text']="Hallo ".$data['resident_name']."! Geef hieronder je handtekening alsjeblieft. Zo beloven wij dat jouw ingevulde vragenlijst ook echt door jou werd ingevuld.";
		$this->parser->parse('first_signature', $data);
	}

	public function signaturePageManage() {
		$data = $this->getTom();
		$data['next_link'] = 'editResident';
		$data['tom_text']="Hallo! Geef hieronder je handtekening alsjeblieft. Zo zijn wij er zeker van dat jouw ingevulde vragenlijst ook echt door jou werd ingevuld.";
		$this->parser->parse('first_signature', $data);
	}


	public function firstSignParser() {
		$data['survey'] = $this->lang->line('survey');
		$data['home'] = $this->lang->line('home');
		$data['manage'] = $this->lang->line('manage');
		$data['paragraph'] = $this->lang->line('paragraph_first_sign');
		$data['h1_title'] = $this->lang->line('h1_first_sign');
		$data['btn_go_on'] = $this->lang->line('btn_go_on');
		$data['btn_cancel'] = $this->lang->line('btn_cancel');

		return $data;
	}

}


