<?php

/* Home */
$lang['survey'] = 'Vragenlijst';
$lang['home'] = 'Home';
$lang['manage'] = 'Beheer';

/* Manage */
$lang['results'] = 'Resultaten';
$lang['residents'] = 'Bewoners';
$lang['lottery'] = 'Loterij';

/* Select Resident */
$lang['title_select_resident'] = 'Selecteer bewoner voor vragenlijst';
$lang['resident_b'] = 'Bewoner';
$lang['search_resident_on_name'] = 'zoek bewoner op naam';
$lang['btn_add_resident'] = 'Voeg bewoner toe';
$lang['btn_start'] = 'Start';
$lang['search'] = 'Zoek';
$lang['name'] = 'Naam';
$lang['room_number'] = 'Kamernummer';
$lang['latest'] = 'Laatste';

/* Manage Resident */
$lang['title_manage_resident'] = 'Selecteer bewoner om aan te passen';
$lang['btn_edit_resident'] = 'Bewerk';
$lang['show_allInactive']="Toon alle nonactieve bewoners";
$lang['show_allWOSig']="Toon alle bewoners zonder handtekening";
$lang['resident_label'] = "Bewoner";
$lang['resident_field_label'] = "zoek bewoner op naam";
$lang['name_label'] = "zoek bewoner op naam";

/* Edit Resident */
$lang['title_edit_resident'] = 'Wijzig hier de gegevens van de bewoners';
$lang['active'] = 'Actief';
$lang['nonactive'] = 'Nonactief';
$lang['save'] = 'Bewaar';
$lang['signature_btn'] = 'Voeg een handtekening toe';

/* Lottery Page */
$lang['title_lottery'] = 'Kies de tijdsperiode waarin een vragenlijst moet ingevuld zijn';
$lang['last_week'] = 'Afgelopen week';
$lang['last_month'] = 'Afgelopen maand';
$lang['last_half_year'] = 'Afgelopen half jaar';
$lang['last_year'] = 'Afgelopen jaar';
$lang['btn_lottery'] = 'Kies willekeurige winnaar';

/* Lotterywinner Page */
$lang['title_lotterywinner'] = 'De winnaar van de loterij is:';

/* Signup Page */
$lang['add_new_user'] = 'Nieuwe zorgverlener';
$lang['first_name'] = 'Voornaam';
$lang['last_name'] = 'Achternaam';
$lang['username'] = 'Gebruikersnaam';
$lang['email'] = 'Email';
$lang['password'] = 'Wachtwoord';
$lang['administrator_check'] = 'Vink aan voor administrator functie';
$lang['admincheck_explanation'] = 'Zorgverleners met administrator functie kunnen nieuwe zorgverleners toevoegen';
$lang['btn_new_user'] = 'Voeg toe';
$lang['btn_cancel'] = 'Annuleer';
$lang['avatar_text'] = 'Klik op de avatar om een andere te kiezen';

/* Edit account page */
$lang['edit_user'] = 'Bewerk uw account';
$lang['btn_edit_account'] = 'Bewaar';
$lang['old_password'] = 'Huidige wachtwoord';
$lang['new_password'] = 'Nieuwe wachtwoord';
$lang['modal_password_title'] = 'Voer uw huidige en nieuwe wachtwoord in';
$lang['btn_password'] = "Verander wachtwoord";

/* Add resident Page */
$lang['title_add_resident'] = 'Gegevens bewoner';
$lang['birth_year'] = 'Geboortejaar';
$lang['gender'] = 'Geslacht';
$lang['activity'] = 'Activiteit';
$lang['male'] = 'Man';
$lang['female'] = 'Vrouw';
$lang['btn_add'] = 'Voeg toe';

/* First signature page */
$lang['paragraph_first_sign'] = 'De volgende pagina is de pagina waar de bewoner zijn of haar handtekening moet invullen. Deze zal later gebruikt worden om zeker te zijn dat het een bewoner is die de vragenlijst in vult.';
$lang['h1_first_sign'] = 'Uitleg betreffende handtekening';
$lang['btn_go_on'] = 'Ga verder';

//Charts
$lang['chartcat_title_h1'] = "Resultaten van de categorie ";
$lang['chartind_title_h1'] = "Resultaten van de bewoner: ";
$lang['charts_clickoncat'] = "Klik op een categorie om deze in detail te bekijken.";
$lang['charts_compareWglobal']="Vergelijk met globale resultaten:";
$lang['charts_overzicht']="Overzicht";
$lang['charts_progressie']="Progressie";
$lang['charts_individual']="Individuele niet-anonieme resultaten";
$lang['charttitleOverview']= "Gemiddelde resultaten per categorie";
$lang['charttitleOverviewCat']= "Gemiddelde resultaten per vraag van categorie: ";
$lang['charttitleOverviewInd']= "Gemiddelde resultaten per categorie van persoon";
$lang['charts_stacked']="Spreiding per vraag";
$lang['De progressie']="De gemiddelde progressie";
$lang['charttitleProgCategory'] = "van de categorie: ";
$lang['charttitleProgInd'] = "van de persoon ";
$lang['charts_progresspast']="Bekijk de progressie van afgelopen...";
$lang['charts_individualtab_h1']="Bekijk de resultaten van alle bewoners die een vragenlijst niet anoniem hebben ingevuld";
$lang['jaar']="jaar";
$lang['maand']="maand";
$lang['maanden']="maanden";
$lang['maandelijks']="maandelijks";
$lang['jaarlijks'] = "jaarlijks";
$lang['charts_stacktitle']="Aantal antwoorden per vraag van";
$lang['backToOverview']="Ga terug naar het globale overzicht";

//Warning messages
$lang['username_warning_message'] = "Gebruikersnaam bestaat al. Kies een andere.";
$lang['username_success_message'] = "Zorgverlener aangemaakt. U wordt terugestuurd naar de homepage.";
$lang['username_edit_success_message'] = "Zorgverlener bewerkt. U wordt terugestuurd naar de homepage.";
$lang['password_warning_message'] = "Ingegeven wachtwoord was fout.";
$lang['password_correct_message'] = "Uw wachtwoord is aangepast.";

//Titles in browser tab
$lang['home_title_tab'] = "Home | UXWD NH Survey";
$lang['signup_title_tab'] = "Nieuwe zorgverlener | UXWD NH Survey";
$lang['editAccount_title_tab'] = "Bewerk account | UXWD NH Survey";
$lang['manage_title_tab'] = "Beheer | UXWD NH Survey";
$lang['editResident_title_tab'] = "Wijzig gegevens bewoner | UXWD NH Survey";
$lang['addResident_title_tab'] = "Voeg bewoner toe | UXWD NH Survey";
$lang['lottery_title_tab'] = "Kies een loterij winnaar | UXWD NH Survey";
$lang['lottery_success_title_tab'] = "Loterij winnaar | UXWD NH Survey";
$lang['selectResident_title_tab'] = "Selecteer bewoner | UXWD NH Survey";
$lang['charts_title_tab'] = "Overzicht resultaten | UXWD NH Survey";
$lang['chartscategory_title_tab'] = "Resultaten van ";
$lang['firstSign_title_tab'] = 'Handtekening | UXWD NH Survey';

//Header
$lang['add_resident_header'] = "Voeg een bewoner toe";
$lang['add_resident_cg_header'] = "Voeg een bewoner of zorgverlener toe";
$lang['edit_header'] = "Beheer je account";
$lang['logout_header'] = "Log uit";
$lang['add_caregiver_header'] = "Voeg een zorgverlener toe";

//Button titles
$lang['survey_title'] = "Ga naar Vragenlijst";
$lang['manage_title'] = "Ga naar Beheer";
$lang['results_title'] = "Ga naar Resultaten";
$lang['residents_title'] = "Ga naar Bewoners";
$lang['lottery_title'] = "Ga naar Loterij";
$lang['overview_title'] = "Bekijk de resulaten in het overzicht";
$lang['progress_title'] = "Bekijk de progressie van de resultaten";
$lang['individual_title'] = "Bekijk de individuele resultaten";
$lang['month_title'] = "Bekijk de progressie van de afgelopen maand";
$lang['months_title'] = "Bekijk de progressie van de afgelopen drie maanden";
$lang['half_year_title'] = "Bekijk de progressie van het afgelopen halve jaar";
$lang['year_title'] = "Bekijk de progressie van het afgelopen jaar";
$lang['distribution_title'] = "Bekijk de spreiding van de resultaten";
$lang['overview_btn_title'] = "Ga terug naar het globale overzicht van de resultaten";
$lang['person_btn_title'] = "Ga terug naar het overzicht van deze bewoner";
$lang['lottery_btn_title'] = "Kies een willekeurige winnaar";
$lang['add_btn_title'] = "Voeg een nieuwe bewoner toe";
$lang['start_survey_title'] = "Start de enquête";
$lang['add_resident_title'] = "Voeg deze bewoner toe";
$lang['cancel_btn_title'] = "Annuleer en ga terug";
$lang['male_btn_title'] = "Deze bewoner is een man";
$lang['female_btn_title'] = "Deze bewoner is een vrouw";
$lang['save_btn_title'] = "Bewaar deze gegevens";
$lang['active_btn_title'] = "Deze bewoner heeft een actieve status";
$lang['nonactive_btn_title'] = "Deze bewoner heeft een nonactieve status";
$lang['signature_btn_title'] = "Voeg een handtekening toe voor deze bewoner";
$lang['add_btn_cg_title'] = "Voeg deze zorgverlener toe";
$lang['change_password_title'] = "Verander uw wachtwoord";


