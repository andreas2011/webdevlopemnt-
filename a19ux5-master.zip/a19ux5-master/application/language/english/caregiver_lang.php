<?php

/* Home */
$lang['survey'] = 'Survey';
$lang['home'] = 'Home';
$lang['manage'] = 'Manage';

/* Manage */
$lang['results'] = 'Results';
$lang['residents'] = 'Residents';
$lang['lottery'] = 'Lottery';

/* Select Resident */
$lang['title_select_resident'] = 'Select resident for survey';
$lang['resident_b'] = 'RESIDENT';
$lang['search_resident_on_name'] = 'search resident by name';
$lang['btn_add_resident'] = 'Add resident';
$lang['btn_start'] = 'Start';
$lang['search'] = 'Search';
$lang['name'] = 'Name';
$lang['room_number'] = 'Room number';
$lang['latest'] = 'Latest';

/* Manage Resident */
$lang['title_manage_resident'] = 'Select resident to edit';
$lang['btn_edit_resident'] = 'Edit';
$lang['show_allInactive']="Show all inactive residents";
$lang['show_allWOSig']="Show all residents without signature";
$lang['resident_label'] = "Resident";
$lang['resident_field_label'] = "search resident by name";

/* Edit Resident */
$lang['title_edit_resident'] = 'Edit here the information of the resident.';
$lang['active'] = 'Active';
$lang['nonactive'] = 'Non active';
$lang['save'] = 'Save';
$lang['signature_btn'] = 'Add a signature';

/* Lottery Page */
$lang['title_lottery'] = 'Choose the time period in which the survey had to be filled in';
$lang['last_week'] = 'Last week';
$lang['last_month'] = 'Last month';
$lang['last_half_year'] = 'Last half year';
$lang['last_year'] = 'Last year';
$lang['btn_lottery'] = 'Choose random winner';

/* Lotterywinner Page */
$lang['title_lotterywinner'] = 'The winner of the lottery is:';

/* Signup Page */
$lang['add_new_user'] = 'New caregiver';
$lang['first_name'] = 'First name';
$lang['last_name'] = 'Last name';
$lang['username'] = 'Username';
$lang['email'] = 'Email';
$lang['password'] = 'Password';
$lang['administrator_check'] = 'Check for administrator function';
$lang['admincheck_explanation'] = 'Caregivers with this administrator function can add new caregivers';
$lang['btn_new_user'] = 'Add';
$lang['btn_cancel'] = 'Cancel';
$lang['avatar_text'] = 'Click on avatar to choose another one';

/* Edit account page */
$lang['edit_user'] = 'Edit your account';
$lang['btn_edit_account'] = 'Save';
$lang['old_password'] = 'Current password';
$lang['new_password'] = 'New password';
$lang['modal_password_title'] = 'Fill in your current password and your new one';
$lang['btn_password'] = "Change password";

/* Add resident Page */
$lang['title_add_resident'] = 'Resident information';
$lang['birth_year'] = 'Birth year';
$lang['gender'] = 'Gender';
$lang['activity'] = 'Activity';
$lang['male'] = 'Male';
$lang['female'] = 'Female';
$lang['btn_add'] = 'Add';

/* First signature page */
$lang['title_first_sign'] = 'Signature | UXWD NH Survey';
$lang['paragraph_first_sign'] = 'The next page is the page where the resident needs to sign his or her signature. It wil be used later on to make sure it is a resident who fills in the survey.';
$lang['h1_first_sign'] = 'Explanation concerning the signature';
$lang['btn_go_on'] = 'Continue';

//Charts
$lang['chartcat_title_h1'] = "Results of the category ";
$lang['chartind_title_h1'] = "Results of the resident: ";
$lang['charts_clickoncat'] = "Click on a category to view this in detail.";
$lang['charts_compareWglobal']="Compare with the global results:";
$lang['charts_overzicht']="Overview";
$lang['charts_progressie']="Progression";
$lang['charttitleOverview']= "Average results for each category ";
$lang['charttitleOverviewCat']= "Average results for each question of category: ";
$lang['charttitleOverviewInd']= "Average results for each category of person";
$lang['charts_individual']="Indiviual non anonymous results";
$lang['charts_stacked']="Distribution for each question";
$lang['De progressie']="The averaged progression";
$lang['charttitleProgCategory'] = "of category: ";
$lang['charttitleProgInd'] = "of person ";
$lang['charts_progresspast']="Check the progression of past...";
$lang['charts_individualtab_h1']="Check results of all residents who filled in a survey non anonymous";
$lang['jaar']="year";
$lang['maand']="month";
$lang['maanden']="months";
$lang['maandelijks']="monthly";
$lang['jaarlijks'] = "yearly";
$lang['charts_stacktitle']="Number of answers for each question";
$lang['backToOverview']="Go back to the global overview";

//Warning messages
$lang['username_warning_message'] = "Username already exists. Choose another one.";
$lang['username_success_message'] = "Caregiver profile added. You are being send back to the homepage.";
$lang['username_edit_success_message'] = "Caregiver profile edited. You are being send back to the homepage.";
$lang['password_warning_message'] = "Inserted password is wrong.";
$lang['password_correct_message'] = "Your password has been changed.";

//Titles in browser tab
$lang['home_title_tab'] = "Home | UXWD NH Survey";
$lang['signup_title_tab'] = "New caregiver | UXWD NH Survey";
$lang['editAccount_title_tab'] = "Edit account | UXWD NH Survey";
$lang['manage_title_tab'] = "Manage | UXWD NH Survey";
$lang['editResident_title_tab'] = "Edit resident information | UXWD NH Survey";
$lang['addResident_title_tab'] = "Add resident | UXWD NH Survey";
$lang['lottery_title_tab'] = "Choose a lottery winner | UXWD NH Survey";
$lang['lottery_success_title_tab'] = "Lottery winner | UXWD NH Survey";
$lang['selectResident_title_tab'] = "Select resident | UXWD NH Survey";
$lang['charts_title_tab'] = "Overview results | UXWD NH Survey";
$lang['chartscategory_title_tab'] = "Results of ";
$lang['firstSign_title_tab'] = 'Signature | UXWD NH Survey';

//Header
$lang['add_resident_header'] = "Add a resident";
$lang['add_resident_cg_header'] = "Add a resident or caregiver";
$lang['edit_header'] = "Edit your account";
$lang['logout_header'] = "Logout";
$lang['add_caregiver_header'] = "Add a caregiver";

//Button titles
$lang['survey_title'] = "Go to Survey";
$lang['manage_title'] = "Go to Manage";
$lang['results_title'] = "Go to Results";
$lang['residents_title'] = "Go to Residents";
$lang['lottery_title'] = "Go to Lottery";
$lang['overview_title'] = "Check the results in the overview";
$lang['progress_title'] = "Check the progression of the results";
$lang['individual_title'] = "Check the individual results";
$lang['month_title'] = "Check the progression of the past month";
$lang['months_title'] = "Check the progression of the past three months";
$lang['half_year_title'] = "Check the progression of the past half year";
$lang['year_title'] = "Check the progression of the past year";
$lang['distribution_title'] = "Check the distribution of the results";
$lang['overview_btn'] = "Go back to the global overview";
$lang['overview_btn_title'] = "Go back to the global overview of the results";
$lang['person_btn_title'] = "Go back to the overview of this resident";
$lang['lottery_btn_title'] = "Choose a random winner";
$lang['add_btn_title'] = "Add a new resident";
$lang['start_survey_title'] = "Start the survey";
$lang['add_resident_title'] = "Add this resident";
$lang['cancel_btn_title'] = "Cancel and go back";
$lang['male_btn_title'] = "This resident is a man";
$lang['female_btn_title'] = "This resident is a woman";
$lang['save_btn_title'] = "Save this information";
$lang['active_btn_title'] = "This resident has an active status";
$lang['nonactive_btn_title'] = "This resident has a nonactive status";
$lang['signature_btn_title'] = "Add a signature for this resident";
$lang['add_btn_cg_title'] = "Add this caregiver";
$lang['change_password_title'] = "Change your password";

